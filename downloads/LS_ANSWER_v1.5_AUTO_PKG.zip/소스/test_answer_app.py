"""Run: python -m unittest discover -s . -v (sample input folder via LS_SAMPLE_DIR)."""
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from collections import Counter
from xml.etree import ElementTree as ET
import answer_app as app

BASE=Path(os.environ.get('LS_SAMPLE_DIR',''))
HAS_SAMPLES=bool(os.environ.get('LS_SAMPLE_DIR')) and BASE.is_dir()

def mutate(source,target,sheet,address,value):
    wb=app.Xlsx(source);root=wb.sheets[sheet]
    row=next(r for r in root.find(app.tag('sheetData')) if r.get('r')==''.join(filter(str.isdigit,address)))
    app.setcell(row,''.join(filter(str.isalpha,address)),value)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in wb.parts.items():
            z.writestr(name,app.serialize_xml(root,app.namespace_map(data)) if name==wb.sheetpaths[sheet] else data)

class UnitTests(unittest.TestCase):
    def cargo(self,weights,awbs):
        ps=[app.Package(str(i+1),'T1',(1000,2000,3000),i+6,{10:w}) for i,w in enumerate(weights)]
        rows=[app.ShipmentRow('Pricing',i+2,'T1',awb,pcs,(1000,2000,3000),weight,100,None,None,'','','') for i,(awb,pcs,weight) in enumerate(awbs)]
        return ps,rows
    def test_auto_distinguishes_same_size_by_weight(self):
        ps,rows=self.cargo([100,200],[('11111111111',1,200),('22222222222',1,100)])
        app.assign(ps,rows,[],mode='auto')
        self.assertEqual([r.pkgs for r in rows],[['2'],['1']])
        self.assertTrue(all(r.match_status=='자동매칭' for r in rows))
    def test_auto_capacity_matching_avoids_greedy_weight_trap(self):
        ps,rows=self.cargo([100,101.5],[('11111111111',1,100.8),('22222222222',1,99.1)])
        app.assign(ps,rows,[],mode='auto')
        self.assertEqual([r.pkgs for r in rows],[['2'],['1']])
        self.assertEqual(len({p for r in rows for p in r.pkgs}),2)
        self.assertTrue(all(r.match_status=='자동매칭' for r in rows))
    def test_auto_alternative_weight_assignments_are_pending(self):
        ps,rows=self.cargo([100,101],[('11111111111',1,100.5),('22222222222',1,100.5)])
        app.assign(ps,rows,[],mode='auto',settings={'auto_assign_estimates':False,'weight_tolerance_kg':1,'weight_tolerance_percent':0})
        self.assertTrue(all(r.match_status=='확인필요' for r in rows))
    def test_auto_identical_packages_multiple_awbs_are_pending(self):
        ps,rows=self.cargo([100,100],[('11111111111',1,100),('22222222222',1,100)])
        app.assign(ps,rows,[],mode='auto',settings={'auto_assign_estimates':False})
        self.assertTrue(all(r.match_status=='확인필요' for r in rows))
        self.assertTrue(all(r.candidate_pkgs==['1','2'] for r in rows))
    def test_auto_identical_packages_same_awb_are_grouped(self):
        ps,rows=self.cargo([100,100],[('11111111111',1,100),('11111111111',1,100)])
        app.assign(ps,rows,[],mode='auto')
        self.assertTrue(all(r.match_status=='자동매칭' for r in rows))
    def test_auto_weight_mismatch_single_awb_is_disclosed(self):
        ps,rows=self.cargo([200,200],[('11111111111',2,100)])
        issues=[];app.assign(ps,rows,issues,mode='auto')
        self.assertEqual(rows[0].pkgs,['1','2'])
        self.assertTrue(any('오차범위 초과' in str(x) for x in issues))
        self.assertEqual(rows[0].match_status,'추정배정')
    def test_auto_weight_mismatch_multiple_awbs_remains_pending(self):
        ps,rows=self.cargo([200,200],[('11111111111',1,100),('22222222222',1,100)])
        app.assign(ps,rows,[],mode='auto',settings={'auto_assign_estimates':False})
        self.assertTrue(all(r.match_status=='확인필요' for r in rows))
    def test_auto_weight_rounding_tolerance(self):
        ps,rows=self.cargo([100.3168],[('11111111111',1,100)])
        app.assign(ps,rows,[],mode='auto',settings={'auto_assign_estimates':False,'weight_tolerance_kg':1,'weight_tolerance_percent':0})
        self.assertEqual(rows[0].match_note,'G.W/PC ±1kg, TASK·치수·PCS 대조')
    def test_auto_identical_packages_are_assigned_with_estimate_labels(self):
        ps,rows=self.cargo([100,100],[('11111111111',1,100),('22222222222',1,100)])
        app.assign(ps,rows,[],mode='auto')
        self.assertEqual([r.pkgs for r in rows],[['1'],['2']])
        self.assertTrue(all(r.match_status=='추정배정' for r in rows))
    def test_auto_prefers_nearest_when_tolerance_is_wide(self):
        ps,rows=self.cargo([100,200],[('11111111111',1,200),('22222222222',1,100)])
        app.assign(ps,rows,[],mode='auto',settings={'weight_tolerance_percent':100})
        self.assertEqual([r.pkgs for r in rows],[['2'],['1']])
        self.assertTrue(all(r.match_status=='자동매칭' for r in rows))
    def test_auto_expanded_tolerance_changes_classification(self):
        for tolerance,expected in [(1,'추정배정'),(30,'자동매칭')]:
            ps,rows=self.cargo([125],[('11111111111',1,100)])
            app.assign(ps,rows,[],mode='auto',settings={'weight_tolerance_kg':0,'weight_tolerance_percent':tolerance})
            self.assertEqual(rows[0].pkgs,['1'])
            self.assertEqual(rows[0].match_status,expected)
    def test_auto_option_validation(self):
        for options in ({'weight_tolerance_kg':-1},{'weight_tolerance_percent':101},{'weight_tolerance_percent':'nan'},{'weight_tolerance_kg':True},{'auto_assign_estimates':'yes'}):
            with self.subTest(options=options):
                with self.assertRaises(ValueError):app.auto_options(options)
        self.assertEqual(app.auto_options({'weight_tolerance_kg':0,'weight_tolerance_percent':0})['weight_tolerance_kg'],0)
    def test_auto_optimizer_matches_exhaustive_minimum(self):
        from itertools import permutations
        import random
        rng=random.Random(147)
        for _ in range(40):
            weights=[rng.choice([80,100,125,180,240]) for _ in range(4)]
            prices=[rng.choice([75,100,120,160,220]) for _ in range(4)]
            ps,rows=self.cargo(weights,[(str(11111111111+i),1,w) for i,w in enumerate(prices)])
            settings={'weight_tolerance_kg':10,'weight_tolerance_percent':15}
            app.assign(ps,rows,[],mode='auto',settings=settings)
            def objective(order):
                pairs=list(zip(order,prices))
                return (sum(abs(w-p)>max(10,p*.15)+1e-9 for w,p in pairs),sum(round(abs(w-p)/p*1000000) for w,p in pairs))
            actual=[weights[int(r.pkgs[0])-1] for r in rows]
            self.assertEqual(objective(actual),min(objective(p) for p in permutations(weights)))
    def test_auto_large_group_has_no_loss_or_duplicates(self):
        weights=[100+100*(i%10) for i in range(2000)]
        ps,rows=self.cargo(weights,[(str(11111111111+i),10,100+100*(i%10)) for i in range(200)])
        app.assign(ps,rows,[],mode='auto')
        ids=[p for r in rows for p in r.pkgs]
        self.assertEqual(len(ids),2000);self.assertEqual(len(set(ids)),2000)
    def test_auto_quantity_mismatch_stops(self):
        ps,rows=self.cargo([100],[('11111111111',2,100)])
        with self.assertRaisesRegex(ValueError,'수량'):app.assign(ps,rows,[],mode='auto')
    def test_explicit_mode_never_fills_missing_pkg(self):
        ps,rows=self.cargo([100],[('11111111111',1,100)])
        with self.assertRaisesRegex(ValueError,'PKG NO.'):app.assign(ps,rows,[],mode='explicit')
    def test_explicit_mode_preserves_requested_package(self):
        ps,rows=self.cargo([100,200],[('11111111111',1,200),('22222222222',1,100)])
        rows[0].explicit=['2'];rows[1].explicit=['1']
        app.assign(ps,rows,[],mode='explicit')
        self.assertEqual([r.pkgs for r in rows],[['2'],['1']])
        self.assertTrue(all(r.match_status=='지정PKG' for r in rows))
    def test_explicit_mode_rejects_duplicate_ids(self):
        ps,rows=self.cargo([100,100],[('11111111111',1,100),('22222222222',1,100)])
        for r in rows:r.explicit=['1']
        with self.assertRaisesRegex(ValueError,'중복'):app.assign(ps,rows,[],mode='explicit')
    def test_invalid_matching_mode_rejected(self):
        ps,rows=self.cargo([100],[('11111111111',1,100)])
        with self.assertRaisesRegex(ValueError,'지원하지'):app.assign(ps,rows,[],mode='invalid')
    def test_awb_normalization(self):
        self.assertEqual(app.awb(' 027-20111512 '),'02720111512')
        self.assertEqual(app.awb(2720111512),'02720111512')
    def test_invalid_awb(self):
        for v in ('ABC','1','123456789012',None):
            with self.assertRaises(ValueError):app.awb(v)
    def test_column_numbers(self):
        for n in (1,14,26,27,31,52,702):self.assertEqual(app.idx(app.col(n)),n)
    def test_numeric_guards(self):
        for v in ('nan','inf',None,True):
            with self.assertRaises(ValueError):app.num(v,'test')
        for v in (0,-1,1.2):
            with self.assertRaises(ValueError):app.integer(v,'test')
        self.assertEqual(app.integer('1,000','test'),1000)
    def test_markup_prefixes_need_real_declarations(self):
        invalid=b'<x xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="xr"/>'
        with self.assertRaisesRegex(ValueError,'xr'):app.validate_markup_namespaces(invalid)
    def test_mc_only_namespace_survives_serialization(self):
        root=ET.Element(app.tag('worksheet'),{'{'+app.MC+'}Ignorable':'x14ac xr xr2 xr3'})
        data=app.serialize_xml(root)
        declared=app.namespace_map(data)
        for prefix in ('x14ac','xr','xr2','xr3'):self.assertIn(prefix,declared)
    def test_undeclared_mc_value_rejected(self):
        root=ET.Element(app.tag('worksheet'),{'{'+app.MC+'}Ignorable':'undefined_vendor'})
        with self.assertRaisesRegex(ValueError,'undefined_vendor'):app.serialize_xml(root)

@unittest.skipUnless(HAS_SAMPLES,'LS_SAMPLE_DIR에 제공 샘플 폴더 지정 필요')
class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cipl=next(BASE.glob('(*.xlsx'))
        cls.pricing=BASE/'Pricing 팀 제공파일.xlsx'
        cls.template=Path(__file__).parent/'answer_template.xlsx'
        cls.selections={'T124':'스케T124 126 127','T125':'스케T125'}
        cls.temp=tempfile.TemporaryDirectory()
        cls.target=Path(cls.temp.name)
        cls.result,cls.manifest=app.run(cls.cipl,cls.pricing,cls.target,cls.selections,cls.template)
        cls.wb=app.Xlsx(cls.result/'ANSWER_검토용.xlsx')
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_default_both_sheets(self):
        self.assertEqual(app.default_selections(self.cipl,self.pricing),self.selections)
    def test_auto_original_without_pkg_splits_all_awbs_and_preserves_source(self):
        folder,manifest=app.run(self.cipl,self.pricing,self.target,self.selections,self.template,{'matching_mode':'auto','auto_assign_estimates':False,'weight_tolerance_kg':1,'weight_tolerance_percent':0})
        self.assertEqual((manifest['packages'],manifest['awbs']),(58,12))
        self.assertEqual((manifest['confirmed_packages'],manifest['pending_packages']),(16,42))
        self.assertEqual(app.hash_file(folder/'Pricing_원본사본.xlsx'),app.hash_file(self.pricing))
        wb=app.Xlsx(folder/'ANSWER_검토용.xlsx')
        actual_pending=[]
        for r in range(6,64):
            if wb.value('Packing List_스케줄',f'W{r}')=='PKG–AWB 확인필요':
                actual_pending.append(r)
                for c in ('Q','R','S','T','U'):self.assertIsNone(wb.value('Packing List_스케줄',f'{c}{r}'))
                self.assertIsNone(wb.value('Packing List_스케줄',f'V{r}'))
        self.assertEqual(len(actual_pending),42)
        for a in manifest['assignments']:
            if a['match_status']=='확인필요':self.assertEqual(a['pkgs'],[]);self.assertTrue(a['candidate_pkgs'])
        self.assertEqual(wb.value('스케쥴','L15'),58)
        self.assertEqual(wb.value('총합 견적서','L13'),2291088000)
    def test_auto_default_assigns_all_58_and_discloses_estimates(self):
        folder,manifest=app.run(self.cipl,self.pricing,self.target,self.selections,self.template,{'matching_mode':'auto'})
        self.assertEqual((manifest['assigned_packages'],manifest['estimated_packages'],manifest['pending_packages']),(58,42,0))
        self.assertEqual(manifest['confirmed_packages'],16)
        ids=[p for a in manifest['assignments'] for p in a['pkgs']]
        self.assertEqual(len(ids),58);self.assertEqual(len(set(ids)),58)
        wb=app.Xlsx(folder/'ANSWER_검토용.xlsx')
        self.assertEqual(sum(wb.value('Packing List_스케줄',f'W{r}')=='추정배정' for r in range(6,64)),42)
        self.assertTrue(all(wb.value('Packing List_스케줄',f'T{r}') is not None for r in range(6,64)))
        self.assertEqual(wb.value('Packing List_스케줄','V5'),'ETA')
        self.assertIn('추정배정 포함',wb.value('총합 견적서','B1'))
        self.assertEqual(manifest['settings']['weight_tolerance_percent'],30)
    def test_auto_ignores_preentered_pkg_identifiers(self):
        target=self.target/'auto_ignore.xlsx'
        mutate(self.pricing,target,'스케T125','N8','INVALID-PKG')
        cb,pb,ps,rows,lookup,issues=app.analyze(self.cipl,target,self.selections,'auto')
        self.assertEqual(sum(r.pcs for r in rows),58)
        self.assertTrue(all(not r.explicit for r in rows))
    def test_explicit_original_missing_pkg_rejected(self):
        with self.assertRaisesRegex(ValueError,'PKG NO.'):app.analyze(self.cipl,self.pricing,self.selections,'explicit')
    def test_explicit_uses_both_sheets_without_reassigning(self):
        source=self.result/'Pricing_PKG배정.xlsx'
        folder,manifest=app.run(self.cipl,source,self.target,self.selections,self.template,{'matching_mode':'explicit'})
        self.assertEqual(manifest['pending_packages'],0)
        self.assertEqual([a['pkgs'] for a in manifest['assignments']],[a['pkgs'] for a in self.manifest['assignments']])
        self.assertTrue(all(a['match_status']=='지정PKG' for a in manifest['assignments']))
    def test_explicit_conflicting_duplicate_sheet_pkg_stops(self):
        source=self.result/'Pricing_PKG배정.xlsx';target=self.target/'explicit_conflict.xlsx'
        mutate(source,target,'스케T125','N2','1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12')
        with self.assertRaisesRegex(ValueError,'두 시트 PKG 불일치'):app.analyze(self.cipl,target,self.selections,'explicit')
    def test_header_collision(self):
        self.assertEqual(app.Xlsx(self.pricing).headers('스케T124 126 127')['H'],'Q')
    def test_packages_and_awbs(self):
        self.assertEqual((self.manifest['packages'],self.manifest['awbs']),(58,12))
        ids=[x for r in self.manifest['assignments'] for x in r['pkgs']]
        self.assertEqual(len(ids),len(set(ids)))
        totals=Counter()
        for r in self.manifest['assignments']:totals[r['task']]+=r['pcs']
        self.assertEqual(totals,{'T124':29,'T125':29})
    def test_expected_allocations(self):
        rows=self.manifest['assignments']
        self.assertEqual(next(r['pkgs'] for r in rows if r['mawb']=='27276223534'),['1','17'])
        self.assertEqual(next(r['pkgs'] for r in rows if r['mawb']=='27276222812'),['50','66'])
    def test_source_unchanged(self):
        for p,digest in self.manifest['source_sha256'].items():self.assertEqual(app.hash_file(p),digest)
    def test_output_sheet_structure(self):
        self.assertEqual(len(self.wb.sheets),17)
        self.assertEqual(list(self.wb.sheets)[:3],['견적조건 및 견적서','스케쥴','Packing List_스케줄'])
        self.assertEqual(list(self.wb.sheets)[3:5],['총합 견적서','분할견적서_1'])
        self.assertIn('분할견적서_12',self.wb.sheets)
    def test_total_quote_all_amounts_read_each_detail_once(self):
        for r in (10,11,12,13,14,15,16,17,18,19,20,21,22,23):
            formula=self.wb.cells['총합 견적서'][f'L{r}'].find(app.tag('f')).text
            expected=','.join(f"'분할견적서_{n}'!L{r}" for n in range(1,13))
            self.assertIn(f'SUM({expected})',formula)
            self.assertIn(f'COUNT({expected})=12',formula)
            self.assertNotIn("'총합 견적서'!",formula)
    def test_total_quote_cached_amounts_and_unknowns(self):
        s='총합 견적서'
        for r in (10,11,12,13,14,15,20):
            self.assertAlmostEqual(self.wb.value(s,f'L{r}'),sum(self.wb.value(f'분할견적서_{n}',f'L{r}') for n in range(1,13)))
        for r in (16,17,18,19):self.assertEqual(self.wb.value(s,f'L{r}'),'미입력')
        for r in (21,22,23):self.assertEqual(self.wb.value(s,f'L{r}'),'미확정')
        self.assertEqual(self.wb.cells[s]['I7'].find(app.tag('f')).text,"'견적조건 및 견적서'!I7")
    def test_total_quote_uses_actual_group_count(self):
        import copy
        for count in (1,16):
            out=app.OutputBook(self.template)
            out.sheets=[('견적조건 및 견적서',copy.deepcopy(self.wb.sheets['견적조건 및 견적서'])),('분할견적서_1',copy.deepcopy(self.wb.sheets['분할견적서_1']))]
            app.total_quote(out,[{'number':n} for n in range(1,count+1)])
            ws=out.sheets[1][1]
            formula=next(c.find(app.tag('f')).text for c in ws.iter(app.tag('c')) if c.get('r')=='L23')
            self.assertIn(f')={count},SUM(',formula)
            self.assertIn(f"'분할견적서_{count}'!L23",formula)
            self.assertNotIn(f"'분할견적서_{count+1}'!L23",formula)
    def test_independent_control_totals(self):
        self.assertEqual(self.wb.value('스케쥴','L15'),58)
        self.assertAlmostEqual(self.wb.value('스케쥴','N15'),194160)
        self.assertAlmostEqual(self.wb.value('견적조건 및 견적서','L12'),4437360)
        # 97,080 chargeable kg per TASK with separate CIPL selling rates.
        self.assertAlmostEqual(self.wb.value('견적조건 및 견적서','L13'),97080*(10100+13500))
    def test_missing_fees_not_zero(self):
        self.assertEqual(self.wb.value('견적조건 및 견적서','L23'),'미확정')
        self.assertEqual(self.wb.value('분할견적서_1','L16'),'미입력')
        self.assertIn('분할견적서_1',self.wb.cells['스케쥴']['S3'].find(app.tag('f')).text)
    def test_dates_as_excel_values(self):
        self.assertIsInstance(self.wb.raw(self.wb.cells['스케쥴']['E3']),(float,int))
        self.assertEqual(self.wb.date(self.wb.raw(self.wb.cells['스케쥴']['E3'])).strftime('%Y-%m-%d'),'2026-10-31')
    def test_no_historical_values_or_external_formulas(self):
        for name,cells in self.wb.cells.items():
            for address,c in cells.items():
                raw=self.wb.raw(c)
                if isinstance(raw,str):
                    self.assertNotIn('LSE-2630325-6-',raw)
                    self.assertNotIn('T185',raw)
                f=c.find(app.tag('f'))
                if f is not None:
                    self.assertNotIn('[1]',f.text)
                    self.assertNotIn('#REF!',f.text)
        self.assertFalse(any('externalLink' in k for k in self.wb.parts))
    def test_mirrored_pricing(self):
        pb=app.Xlsx(self.result/'Pricing_PKG배정.xlsx')
        h=pb.headers('스케T124 126 127')
        pc=h['PKGNO.']
        for r in range(2,8):self.assertEqual(pb.value('스케T124 126 127',f'{pc}{r}'),pb.value('스케T125',f'N{r}'))
        for r in range(8,26):
            if pb.value('스케T124 126 127',f'L{r}') in ('T126','T127'):self.assertIsNone(pb.value('스케T124 126 127',f'{pc}{r}'))
    def test_existing_assignments_preserved(self):
        cb,pb,packages,rows,lookup,issues=app.analyze(self.cipl,self.result/'Pricing_PKG배정.xlsx',self.selections)
        self.assertEqual([r.pkgs for r in rows],[r['pkgs'] for r in self.manifest['assignments']])
    def test_duplicate_package_stops(self):
        target=self.target/'duplicate.xlsx';mutate(self.cipl,target,'PL Attachment','A7',1)
        with self.assertRaisesRegex(ValueError,'중복'):app.analyze(target,self.pricing,self.selections)
    def test_quantity_mismatch_stops(self):
        target=self.target/'quantity.xlsx';mutate(self.pricing,target,'스케T125','O8',100)
        with self.assertRaisesRegex(ValueError,'필요'):app.analyze(self.cipl,target,self.selections)
    def test_dimension_mismatch_stops(self):
        target=self.target/'dimension.xlsx';mutate(self.pricing,target,'스케T125','P8',999)
        with self.assertRaisesRegex(ValueError,'필요'):app.analyze(self.cipl,target,self.selections)
    def test_date_and_weight_warnings(self):
        text=str(self.manifest['issues'])
        for word in ('불일치','출발일 비어','G.W'):self.assertIn(word,text)
    def test_xml_parts_parse(self):
        for name,data in self.wb.parts.items():
            if name.endswith(('.xml','.rels')):ET.fromstring(data)
    def test_excel_compatibility_on_both_outputs(self):
        for filename in ('ANSWER_검토용.xlsx','Pricing_PKG배정.xlsx'):
            app.validate_excel_structure(self.result/filename)
    def test_phonetic_properties_after_sheet_data(self):
        for root in self.wb.sheets.values():
            children=[c.tag.split('}')[-1] for c in root]
            if 'phoneticPr' in children:self.assertLess(children.index('sheetData'),children.index('phoneticPr'))
    def test_source_style_namespace_metadata_preserved(self):
        root=ET.fromstring(self.wb.parts['xl/styles.xml'])
        self.assertEqual(root.get('{'+app.MC+'}Ignorable'),'x14ac x16r2 xr')
        app.validate_markup_namespaces(self.wb.parts['xl/styles.xml'])
    def test_no_previous_output_overwrite(self):
        first_hash=app.hash_file(self.result/'ANSWER_검토용.xlsx')
        new,_=app.run(self.cipl,self.pricing,self.target,self.selections,self.template)
        self.assertNotEqual(new,self.result)
        self.assertEqual(app.hash_file(self.result/'ANSWER_검토용.xlsx'),first_hash)
    def test_summary_core_costs_link_to_details(self):
        for r in (10,11,13,15,20):
            formula=self.wb.cells['견적조건 및 견적서'][f'L{r}'].find(app.tag('f')).text
            self.assertIn(f"'분할견적서_1'!L{r}",formula)
    def test_sixteenth_schedule_does_not_overwrite_conditions(self):
        import copy
        cb,pb,packages,rows,lookup,issues=app.analyze(self.cipl,self.pricing,self.selections)
        groups=[]
        for i in range(16):
            item=copy.deepcopy(rows[0]);item.mawb=f'{90000000000+i}'
            groups.append({'mawb':item.mawb,'rows':[item],'number':i+1})
        out=app.OutputBook(self.template)
        app.quote(out,cb,groups,'견적조건 및 견적서',issues,{},True)
        target=self.target/'sixteen.xlsx';out.save(target)
        book=app.Xlsx(target)
        self.assertIn(groups[-1]['mawb'],book.value('견적조건 및 견적서','L40'))
        self.assertIn('인도조건',book.value('견적조건 및 견적서','C41'))
    def test_division_by_zero_never_uses_numeric_cache(self):
        target=self.target/'zero_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('1/0',32400))
        with self.assertRaisesRegex(ValueError,'입력 수식 오류.*W3'):app.analyze(self.cipl,target,self.selections)
    def test_circular_formula_never_uses_numeric_cache(self):
        target=self.target/'cycle_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('W3',32400))
        with self.assertRaisesRegex(ValueError,'순환'):app.analyze(self.cipl,target,self.selections)
    def test_ref_error_never_uses_numeric_cache(self):
        target=self.target/'ref_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('SUM(#REF!)',32400))
        with self.assertRaisesRegex(ValueError,'입력 수식 오류'):app.analyze(self.cipl,target,self.selections)
    def test_unsupported_valid_formula_cache_is_disclosed(self):
        target=self.target/'unsupported_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('ROUND(32400,0)',32400))
        result=app.analyze(self.cipl,target,self.selections)
        self.assertTrue(any('미지원 수식' in str(x) and 'W3' in str(x) for x in result[-1]))
    def test_mirror_same_awb_and_dimensions_uses_pcs(self):
        first=self.target/'mirror_first.xlsx';target=self.target/'mirror_both.xlsx'
        mutate(self.pricing,first,'스케T124 126 127','F5','36911555025')
        mutate(first,target,'스케T125','F5','36911555025')
        result,_=app.run(self.cipl,target,self.target,self.selections,self.template)
        pb=app.Xlsx(result/'Pricing_PKG배정.xlsx')
        six=pb.value('스케T125','N3').split(', ');three=pb.value('스케T125','N5').split(', ')
        self.assertEqual(len(six),6);self.assertEqual(len(three),3)
        self.assertFalse(set(six)&set(three))
    def test_ambiguous_mirrors_do_not_overwrite_and_are_logged(self):
        first=self.target/'ambiguous_first.xlsx';target=self.target/'ambiguous_both.xlsx'
        mutate(self.pricing,first,'스케T124 126 127','F6','27276223512')
        mutate(first,target,'스케T125','F6','27276223512')
        result,manifest=app.run(self.cipl,target,self.target,self.selections,self.template)
        pb=app.Xlsx(result/'Pricing_PKG배정.xlsx')
        self.assertIsNone(pb.value('스케T125','N5'));self.assertIsNone(pb.value('스케T125','N6'))
        self.assertTrue(any('동기화 생략' in str(x) for x in manifest['issues']))
        review=app.Xlsx(result/'ANSWER_검토용.xlsx')
        self.assertTrue(any('동기화 생략' in str(review.raw(c)) for c in review.cells['검토사항'].values()))
    def test_contents_preserved_and_excluded_from_package_totals(self):
        import re
        book=app.Xlsx(self.cipl);ws=book.sheets['PL Attachment'];data=ws.find(app.tag('sheetData'))
        def shifted(match):
            letters,r=match.groups();return letters+str(int(r)+1 if int(r)>=7 else int(r))
        for e in ws.iter():
            if e.tag==app.tag('row') and int(e.get('r'))>=7:e.set('r',str(int(e.get('r'))+1))
            for attr in ('r','ref','sqref','activeCell'):
                if attr in e.attrib:e.set(attr,re.sub(r'(\$?[A-Z]+\$?)(\d+)',shifted,e.get(attr)))
            if e.tag==app.tag('f') and e.text:e.text=re.sub(r'(\$?[A-Z]+\$?)(\d+)',shifted,e.text)
        row=ET.Element(app.tag('row'),{'r':'7'})
        for c,v in [('F','EXTRA CONTENTS'),('G',2),('H','EA')]:app.setcell(row,c,v)
        data.append(row);data[:]=sorted(data,key=lambda r:int(r.get('r')))
        target=self.target/'contents.xlsx'
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
            for name,content in book.parts.items():z.writestr(name,app.serialize_xml(ws,app.namespace_map(content)) if name==book.sheetpaths['PL Attachment'] else content)
        result,_=app.run(target,self.pricing,self.target,self.selections,self.template)
        output=app.Xlsx(result/'ANSWER_검토용.xlsx');s='Packing List_스케줄'
        self.assertEqual(output.value(s,'E7'),'EXTRA CONTENTS')
        self.assertEqual(output.value(s,'F7'),2)
        self.assertIsNone(output.value(s,'A7'))
        self.assertEqual(output.value(s,'F65'),58)
        self.assertIn('SUMIFS',output.cells[s]['F65'].find(app.tag('f')).text)

if __name__=='__main__':unittest.main(verbosity=2)
