"""LS CIPL + Pricing -> ANSWER. Standard-library-only Windows desktop/CLI app."""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import io
import json
import logging
import math
import os
import re
import sys
import tempfile
import threading
import unicodedata
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
from xml.etree import ElementTree as ET

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKGREL = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'
NAMESPACE_PREFIXES = {
    'r': REL, 'mc': MC,
    'x14ac': 'http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac',
    'x14': 'http://schemas.microsoft.com/office/spreadsheetml/2009/9/main',
    'x15': 'http://schemas.microsoft.com/office/spreadsheetml/2010/11/main',
    'x16r2': 'http://schemas.microsoft.com/office/spreadsheetml/2015/02/main',
    'xr': 'http://schemas.microsoft.com/office/spreadsheetml/2014/revision',
    'xr2': 'http://schemas.microsoft.com/office/spreadsheetml/2015/revision2',
    'xr3': 'http://schemas.microsoft.com/office/spreadsheetml/2016/revision3',
}
WORKSHEET_ORDER = '''sheetPr dimension sheetViews sheetFormatPr cols sheetData sheetCalcPr
sheetProtection protectedRanges scenarios autoFilter sortState dataConsolidate customSheetViews
mergeCells phoneticPr conditionalFormatting dataValidations hyperlinks printOptions pageMargins
pageSetup headerFooter rowBreaks colBreaks customProperties cellWatches ignoredErrors smartTags
drawing legacyDrawing legacyDrawingHF picture oleObjects controls webPublishItems tableParts extLst'''.split()
APP_VERSION = '1.5.0'
MODE_LABELS={'auto':'사이즈·중량 자동분할','explicit':'Pricing PKG 지정','legacy':'기존 임의배정'}
DEFAULT_AUTO={'weight_tolerance_kg':10.0,'weight_tolerance_percent':30.0,'auto_assign_estimates':True}
ET.register_namespace('', NS)
ET.register_namespace('r', REL)
def tag(name): return f'{{{NS}}}{name}'

def namespace_map(data):
    return dict(item for _,item in ET.iterparse(io.BytesIO(data),events=['start-ns']))

def compatibility_prefixes(element):
    prefixes=set()
    for attr,value in element.attrib.items():
        if attr.startswith('{'+MC+'}') or (element.tag=='{'+MC+'}Choice' and attr=='Requires'):
            for token in value.split():
                prefixes.add(token.split(':',1)[0])
    return prefixes

def validate_markup_namespaces(data):
    # XML parsers alone do not check prefixes embedded in mc:Ignorable/Requires values.
    contexts=[]; pending={}
    for event,item in ET.iterparse(io.BytesIO(data),events=['start-ns','start','end']):
        if event=='start-ns': pending[item[0]]=item[1]
        elif event=='start':
            context=dict(contexts[-1]) if contexts else {'xml':'http://www.w3.org/XML/1998/namespace'}
            context.update(pending);pending={};contexts.append(context)
            for prefix in compatibility_prefixes(item):
                if prefix not in context:raise ValueError(f'Excel 호환성 네임스페이스 미정의: {prefix}')
        else:contexts.pop()

def serialize_xml(root, source_namespaces=None):
    aliases={**NAMESPACE_PREFIXES,**(source_namespaces or {})}
    for prefix,uri in aliases.items():
        if prefix and prefix!='xml' and not re.fullmatch(r'ns\d+',prefix):ET.register_namespace(prefix,uri)
    ET.register_namespace('',root.tag.split('}')[0].lstrip('{'))
    result_root=copy.deepcopy(root)
    provisional=ET.tostring(result_root,encoding='utf-8',xml_declaration=True)
    declared=namespace_map(provisional)
    # ElementTree discards unused xmlns declarations, including ones used only by MC values.
    needed=set().union(*(compatibility_prefixes(e) for e in result_root.iter()))
    for prefix in needed:
        if prefix not in declared:
            if prefix not in aliases:raise ValueError(f'Excel 네임스페이스 URI를 찾을 수 없습니다: {prefix}')
            result_root.set('xmlns:'+prefix,aliases[prefix])
    result=ET.tostring(result_root,encoding='utf-8',xml_declaration=True)
    validate_markup_namespaces(result)
    ET.register_namespace('',NS)
    return result

def order_worksheet(root):
    ranks={tag(name):i for i,name in enumerate(WORKSHEET_ORDER)}
    unknown=[x.tag for x in root if x.tag not in ranks]
    if unknown:raise ValueError('지원하지 않는 Excel 시트 요소: '+', '.join(unknown))
    root[:]=sorted(root,key=lambda x:ranks[x.tag])

def validate_excel_structure(path):
    with zipfile.ZipFile(path) as archive:
        bad=archive.testzip()
        if bad:raise ValueError(f'Excel 압축 데이터 손상: {bad}')
        for name in archive.namelist():
            if not name.endswith(('.xml','.rels')):continue
            data=archive.read(name)
            validate_markup_namespaces(data)
            root=ET.fromstring(data)
            if root.tag==tag('worksheet'):
                ranks={tag(n):i for i,n in enumerate(WORKSHEET_ORDER)}
                sequence=[ranks.get(c.tag,-1) for c in root]
                if -1 in sequence or sequence!=sorted(sequence):raise ValueError(f'Excel 시트 XML 순서 오류: {name}')
def norm(v): return re.sub(r'\s+', '', unicodedata.normalize('NFKC', str(v or ''))).upper()
def col(n):
    result = ''
    while n:
        n, r = divmod(n-1, 26)
        result = chr(65+r)+result
    return result
def idx(s):
    n = 0
    for c in s: n = n*26+ord(c)-64
    return n
def num(v, label, positive=False):
    if v is None or isinstance(v, bool): raise ValueError(f'{label}: 숫자가 없습니다.')
    try: n = float(Decimal(str(v).replace(',', '')))
    except Exception as exc: raise ValueError(f'{label}: 숫자 형식 오류 ({v})') from exc
    if not math.isfinite(n) or (positive and n <= 0): raise ValueError(f'{label}: 유효하지 않은 수치 ({v})')
    return n
def integer(v, label):
    n = num(v, label, True)
    if not n.is_integer(): raise ValueError(f'{label}: 정수가 필요합니다.')
    return int(n)
def identifier(v):
    if isinstance(v, (float, int)) and float(v).is_integer(): return str(int(v))
    return str(v).strip()
def awb(v):
    s = re.sub(r'[\s\-‐‑–—]', '', identifier(v))
    if s.isdigit() and len(s) == 10: s = s.zfill(11)
    if not s.isdigit() or len(s) != 11: raise ValueError(f'MAWB 형식 오류: {v}')
    return s
def hash_file(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class Xlsx:
    """Read cells and evaluate only the arithmetic needed by the supplied formats."""
    def __init__(self, path):
        self.path = Path(path).resolve()
        if self.path.suffix.lower() != '.xlsx': raise ValueError('매크로 없는 .xlsx 파일을 선택하세요.')
        with zipfile.ZipFile(self.path) as z:
            if sum(i.file_size for i in z.infolist()) > 200_000_000: raise ValueError('압축 해제 크기가 200MB를 초과합니다.')
            self.parts = {i.filename:z.read(i.filename) for i in z.infolist()}
        root = ET.fromstring(self.parts['xl/workbook.xml'])
        props = root.find(tag('workbookPr'))
        self.epoch = datetime(1904,1,1) if props is not None and props.get('date1904') in ('1','true') else datetime(1899,12,30)
        rels = ET.fromstring(self.parts['xl/_rels/workbook.xml.rels'])
        targets = {r.get('Id'):r.get('Target') for r in rels}
        self.sheets = {}
        self.sheetpaths = {}
        for s in root.find(tag('sheets')):
            target = targets[s.get(f'{{{REL}}}id')]
            path = target.lstrip('/') if target.startswith('/') else 'xl/'+target
            self.sheets[s.get('name')] = ET.fromstring(self.parts[path])
            self.sheetpaths[s.get('name')] = path
        self.strings = []
        if 'xl/sharedStrings.xml' in self.parts:
            for si in ET.fromstring(self.parts['xl/sharedStrings.xml']):
                self.strings.append(''.join(t.text or '' for t in si.iter(tag('t'))))
        self.cells = {name:{c.get('r'):c for c in root.iter(tag('c'))} for name,root in self.sheets.items()}
        self.cache = {}
        self.cached_formula_cells = set()

    def value(self, sheet, address, visiting=None):
        key = (sheet, address)
        if key in self.cache: return self.cache[key]
        c = self.cells[sheet].get(address)
        if c is None: return None
        t, v = c.get('t'), c.find(tag('v'))
        f = c.find(tag('f'))
        if f is not None and f.text:
            visiting = set() if visiting is None else set(visiting)
            if key in visiting: raise ValueError(f'순환 수식: {sheet}!{address}')
            visiting.add(key)
            try: result = self.calc(sheet, f.text, visiting)
            except UnsupportedFormula:
                if t == 'e' or v is None or v.text is None: raise ValueError(f'계산 불가: {sheet}!{address} ={f.text}')
                result = self.raw(c)
                self.cached_formula_cells.add((sheet,address,f.text))
            except (ValueError, TypeError, ZeroDivisionError, OverflowError) as exc:
                raise ValueError(f'입력 수식 오류: {sheet}!{address} ={f.text} ({exc})') from exc
        else: result = self.raw(c)
        self.cache[key] = result
        return result

    def raw(self, c):
        t, v = c.get('t'), c.find(tag('v'))
        if t == 'inlineStr': return ''.join(x.text or '' for x in c.iter(tag('t')))
        if v is None or v.text is None: return None
        if t == 's': return self.strings[int(v.text)]
        if t in ('str','e'): return v.text
        if t == 'b': return v.text == '1'
        try:
            n = float(v.text)
            return int(n) if n.is_integer() else n
        except ValueError: return v.text

    def calc(self, sheet, expression, visiting):
        # No eval: input formulas can execute only this explicit AST allowlist.
        def range_values(match):
            c1,r1,c2,r2=match.groups()
            refs=[f'{col(c)}{r}' for r in range(int(r1),int(r2)+1) for c in range(idx(c1),idx(c2)+1)]
            return '['+','.join(refs)+']'
        e = expression.replace('$','').replace('^','**')
        e = re.sub(r'([A-Z]+)(\d+):([A-Z]+)(\d+)',range_values,e)
        if re.search(r'#(?:REF!|DIV/0!|VALUE!|NAME\?|N/A|NUM!|NULL!)',e,re.I):raise ValueError('Excel 오류 참조')
        try:tree = ast.parse(e, mode='eval')
        except SyntaxError as exc:raise UnsupportedFormula('지원하지 않는 Excel 수식 구문') from exc
        def walk(n):
            if isinstance(n,ast.Expression): return walk(n.body)
            if isinstance(n,ast.Constant) and type(n.value) in (int,float): return n.value
            if isinstance(n,ast.Name) and re.fullmatch(r'[A-Z]+\d+',n.id):
                v = self.value(sheet,n.id,visiting)
                return 0 if v is None else num(v,f'{sheet}!{n.id}')
            if isinstance(n,ast.List): return [walk(x) for x in n.elts]
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd)):
                return -walk(n.operand) if isinstance(n.op,ast.USub) else walk(n.operand)
            if isinstance(n,ast.BinOp):
                a,b = walk(n.left),walk(n.right)
                if isinstance(n.op,ast.Add): return a+b
                if isinstance(n.op,ast.Sub): return a-b
                if isinstance(n.op,ast.Mult): return a*b
                if isinstance(n.op,ast.Div): return a/b
                if isinstance(n.op,ast.Pow) and abs(b)<=12: return a**b
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('MAX','MIN','SUM') and not n.keywords:
                args=[]
                for x in n.args:
                    v=walk(x); args.extend(v if isinstance(v,list) else [v])
                return {'MAX':max,'MIN':min,'SUM':sum}[n.func.id](args)
            raise UnsupportedFormula('지원하지 않는 수식')
        return walk(tree)

    def headers(self,sheet):
        result={}
        for i in range(1,60):
            v=self.value(sheet,f'{col(i)}1')
            if v is not None:result.setdefault(norm(v),col(i))
        return result

    def date(self, v):
        if v is None or v == '': return None
        if isinstance(v,(int,float)): return self.epoch+timedelta(days=v)
        for fmt in ('%Y-%m-%d','%Y/%m/%d'):
            try:return datetime.strptime(str(v).strip(),fmt)
            except ValueError: pass
        return str(v).strip()

@dataclass
class Package:
    id: str
    task: str
    dims: tuple
    row: int
    data: dict
    details: list = field(default_factory=list)

class UnsupportedFormula(ValueError):
    pass

@dataclass
class ShipmentRow:
    sheet: str
    row: int
    task: str
    mawb: str
    pcs: int
    dims: tuple
    gross_pc: float
    cwt: float
    received: object
    etd: object
    airline: str
    skd: str
    dest: str
    pkgs: list = field(default_factory=list)
    explicit: list = field(default_factory=list)
    match_status: str = '기존 배정'
    candidate_pkgs: list = field(default_factory=list)
    match_note: str = ''

def read_packages(book):
    if 'PL Attachment' not in book.sheets: raise ValueError('CIPL에 PL Attachment 시트가 없습니다.')
    s='PL Attachment'
    if 'TASK' not in norm(book.value(s,'C5')) or 'PKG' not in norm(book.value(s,'A5')):
        raise ValueError('CIPL 표 구조가 예제와 다릅니다. A5 PKG / C5 TASK를 확인하세요.')
    result=[]; seen=set();parent=None
    for r in sorted({int(re.search(r'\d+',a).group()) for a in book.cells[s]}):
        if r<6:continue
        if norm(book.value(s,f'E{r}')).rstrip(':') in ('TOTAL','합계','총계'):
            parent=None
            continue
        task=norm(book.value(s,f'C{r}'))
        raw=book.value(s,f'A{r}')
        if not re.fullmatch(r'T\d+',task) or raw is None:
            description=book.value(s,f'F{r}')
            quantity=book.value(s,f'G{r}')
            unit=book.value(s,f'H{r}')
            if raw is None and description is not None and (quantity is not None or unit is not None):
                if parent is None or (task and task!=parent.task):raise ValueError(f'CIPL {r}행: 구성품의 상위 PKG를 확인할 수 없습니다.')
                if quantity is not None:num(quantity,f'CIPL G{r}',True)
                parent.details.append({c:book.value(s,f'{col(c)}{r}') for c in (6,7,8,9,10,11,13,15,16)})
            elif raw is not None:parent=None
            elif re.fullmatch(r'T\d+',task):raise ValueError(f'CIPL {r}행: PKG 번호가 없습니다.')
            continue
        pid=identifier(raw)
        if pid in seen: raise ValueError(f'CIPL PKG 중복: {pid}')
        seen.add(pid)
        # Read only business columns: unrelated pre-existing #REF! is not a prerequisite.
        values={c:book.value(s,f'{col(c)}{r}') for c in [1,2,3,5,6,7,8,9,10,11,13,15,16,19]}
        dims=tuple(integer(values[c],f'CIPL {col(c)}{r}') for c in (11,13,15))
        for c in (7,9,10,16): num(values[c],f'CIPL {col(c)}{r}',True)
        parent=Package(pid,task,dims,r,values)
        result.append(parent)
    if not result: raise ValueError('CIPL에서 PKG를 찾지 못했습니다.')
    return result

def read_pricing(book, selections, tasks, issues, use_explicit=True):
    result=[]
    for task in tasks:
        s=selections.get(task)
        if not s or s not in book.sheets: raise ValueError(f'{task}: 적용할 Pricing 시트를 선택하세요.')
        h=book.headers(s)
        required=['TASK','MAWB','PCS','L','W','H','GWTPC','TTLPIVOTCWT','입고일','출발일','항공사','SKD','DEST']
        missing=[k for k in required if k not in h]
        if missing: raise ValueError(f'{s} 필수 열 누락: {", ".join(missing)}')
        def v(k,r):return book.value(s,f'{h[k]}{r}')
        for r in sorted({int(re.search(r'\d+',a).group()) for a in book.cells[s]}):
            if r<=1 or norm(v('TASK',r))!=task or v('MAWB',r) is None: continue
            count=integer(v('PCS',r),f'{s}!PCS{r}')
            dims=tuple(integer(Decimal(str(v(k,r)))*10,f'{s}!{k}{r}') for k in ('L','W','H'))
            raw_awb=v('MAWB',r); mawb=awb(raw_awb)
            if identifier(raw_awb).strip()!=mawb: issues.append(('정보',s,r,mawb,'AWB 정규화: 공백·하이픈 제거 / 10자리 앞 0 복원'))
            cwt=num(v('TTLPIVOTCWT',r),f'{s}!CWT{r}',True)
            item=ShipmentRow(s,r,task,mawb,count,dims,num(v('GWTPC',r),f'{s}!GWT{r}',True),cwt,
                book.date(v('입고일',r)),book.date(v('출발일',r)),str(v('항공사',r) or ''),str(v('SKD',r) or ''),str(v('DEST',r) or ''))
            pcol=h.get('PKGNO.') or h.get('PKGNO') or h.get('PKG')
            raw=book.value(s,f'{pcol}{r}') if use_explicit and pcol else None
            if use_explicit and raw is not None and not str(raw).upper().startswith('EX'):
                item.explicit=[x.strip() for x in re.split(r'[,，\n]+',identifier(raw)) if x.strip()]
            if not item.etd: issues.append(('확인필요',s,r,mawb,'출발일 비어 있음. SKD에서 임의 확정하지 않음'))
            dates=re.findall(r'(?<!\d)(\d{1,2})\.(\d{1,2})(?!\d)',item.skd)
            if dates and isinstance(item.etd,datetime) and (item.etd.month,item.etd.day)!=tuple(map(int,dates[0])):
                issues.append(('확인필요',s,r,mawb,f'출발일 {item.etd:%m/%d} / SKD {dates[0][0]}/{dates[0][1]} 불일치'))
            result.append(item)
    if not result: raise ValueError('선택 시트에 CIPL TASK에 해당하는 Pricing 데이터가 없습니다.')
    return result

def auto_options(settings=None):
    options={k:(settings or {}).get(k,v) for k,v in DEFAULT_AUTO.items()}
    for key,label in [('weight_tolerance_kg','중량 오차 kg'),('weight_tolerance_percent','중량 오차 %')]:
        options[key]=num(options[key],label)
        if options[key]<0:raise ValueError(label+'는 0 이상이어야 합니다.')
    if options['weight_tolerance_percent']>100:raise ValueError('중량 오차 %는 100 이하여야 합니다.')
    if type(options['auto_assign_estimates']) is not bool:raise ValueError('추정 포함 배정 설정은 참/거짓이어야 합니다.')
    return options


def weight_tolerance(row,options):
    return max(options['weight_tolerance_kg'],row.gross_pc*options['weight_tolerance_percent']/100)


def weight_rule(options):
    kg,pct=options['weight_tolerance_kg'],options['weight_tolerance_percent']
    return f'G.W/PC ±max({kg:g}kg, {pct:g}%)' if pct else f'G.W/PC ±{kg:g}kg'


def assign_auto_strict(packages,rows,issues,options):
    """Match weight-class capacities; ambiguous physical IDs never become confirmed AWB links."""
    from bisect import bisect_left,bisect_right
    from collections import deque
    pools=defaultdict(list);targets=defaultdict(list)
    for p in packages:pools[(p.task,p.dims)].append(p)
    for r in rows:targets[(r.task,r.dims)].append(r)
    for key in pools.keys()|targets.keys():
        ps=sorted(pools[key],key=lambda p:(0,int(p.id)) if p.id.isdigit() else (1,p.id))
        rs=targets[key]
        if sum(r.pcs for r in rs)!=len(ps):raise ValueError(f'{key}: 치수별 CIPL 수량 {len(ps)} / Pricing 수량 {sum(r.pcs for r in rs)} 불일치')
        classes=defaultdict(list)
        for p in ps:classes[num(p.data[10],f'PKG {p.id} G.W',True)].append(p)
        weights=sorted(classes);graph=defaultdict(dict);eligible=defaultdict(set)
        def edge(a,b,capacity):graph[a][b]=capacity;graph[b][a]=0
        for j,w in enumerate(weights):edge(('w',j),'sink',len(classes[w]))
        edges=0
        for i,r in enumerate(rs):
            edge('source',('r',i),r.pcs)
            tolerance=weight_tolerance(r,options)
            for j in range(bisect_left(weights,r.gross_pc-tolerance),bisect_right(weights,r.gross_pc+tolerance)):
                edge(('r',i),('w',j),r.pcs);eligible[j].add(r.mawb);edges+=1
                if edges>300000:raise ValueError('동일 치수·유사 중량 후보가 30만 건을 초과합니다. Pricing을 TASK별로 나눠주세요.')
        flow=0
        while True:
            parents={'source':None};queue=deque(['source'])
            while queue and 'sink' not in parents:
                a=queue.popleft()
                for b,capacity in graph[a].items():
                    if capacity>0 and b not in parents:parents[b]=a;queue.append(b)
            if 'sink' not in parents:break
            capacity=len(ps);b='sink'
            while parents[b] is not None:
                a=parents[b];capacity=min(capacity,graph[a][b]);b=a
            b='sink'
            while parents[b] is not None:
                a=parents[b];graph[a][b]-=capacity;graph[b][a]+=capacity;b=a
            flow+=capacity
        if flow==len(ps):
            for j,w in enumerate(weights):
                possible_awbs={r.mawb for i,r in enumerate(rs) if graph[('w',j)].get(('r',i),0)>0}
                if len(eligible[j])>1 and len(possible_awbs)==1:
                    # Alternative full assignments differ by residual cycles; impossible edges must not create false ambiguity.
                    reachable={('w',j)};queue=deque([('w',j)])
                    while queue:
                        a=queue.popleft()
                        for b,capacity in graph[a].items():
                            if capacity>0 and isinstance(b,tuple) and b not in reachable:reachable.add(b);queue.append(b)
                    possible_awbs.update(r.mawb for i,r in enumerate(rs) if ('r',i) in reachable and graph[('r',i)].get(('w',j),0)>0)
                offset=0
                for i,r in enumerate(rs):
                    count=graph[('w',j)].get(('r',i),0)
                    if count:
                        r.pkgs.extend(p.id for p in classes[w][offset:offset+count]);offset+=count
                        if len(possible_awbs)>1:r.match_status='확인필요'
            for r in rs:
                if r.match_status!='확인필요':r.match_status='자동매칭'
                r.match_note=weight_rule(options)+', TASK·치수·PCS 대조'
        else:
            # Pricing and CIPL may use different gross-weight bases; retain quantity splits, never invent a weight match.
            offset=0;single_awb=len({r.mawb for r in rs})==1
            for r in rs:
                r.pkgs=[p.id for p in ps[offset:offset+r.pcs]];offset+=r.pcs
                r.match_status='자동매칭' if single_awb else '확인필요'
                r.match_note='중량 조건 불일치 / '+('동일 TASK·치수 전량이 한 AWB로 연결됨' if single_awb else '치수·수량별 물량 분할만 수행, PKG–AWB 미확정')
                issues.append(('확인필요',r.sheet,r.row,r.mawb,r.match_note))
        for r in rs:
            if len(r.pkgs)!=r.pcs:raise RuntimeError('자동분할 수량 검증 실패')
            if r.match_status=='확인필요':
                r.candidate_pkgs=[p.id for p in ps]
                r.match_note+=' / 동일 조건 화물의 실제 PKG–AWB 연결 확인 필요'
                issues.append(('확인필요',r.sheet,r.row,r.mawb,r.match_note))
            else:issues.append(('자동매칭',r.sheet,r.row,r.mawb,', '.join(r.pkgs)+' / '+r.match_note))


def assign_auto(packages,rows,issues,settings=None):
    """Assign all compatible-size quantities, minimizing outside-tolerance count then total weight error."""
    import heapq
    from collections import deque
    options=auto_options(settings)
    if not options['auto_assign_estimates']:return assign_auto_strict(packages,rows,issues,options)
    pools=defaultdict(list);targets=defaultdict(list)
    for p in packages:pools[(p.task,p.dims)].append(p)
    for r in rows:targets[(r.task,r.dims)].append(r)
    for key in sorted(pools.keys()|targets.keys()):
        ps=sorted(pools[key],key=lambda p:(0,int(p.id)) if p.id.isdigit() else (1,p.id));rs=targets[key]
        if sum(r.pcs for r in rs)!=len(ps):raise ValueError(f'{key}: 치수별 CIPL 수량 {len(ps)} / Pricing 수량 {sum(r.pcs for r in rs)} 불일치')
        classes=defaultdict(list)
        for p in ps:classes[num(p.data[10],f'PKG {p.id} G.W',True)].append(p)
        weights=sorted(classes)
        if len(weights)*len(rs)>300000:raise ValueError('동일 치수의 중량 후보가 30만 건을 초과합니다. Pricing을 TASK별로 나눠주세요.')
        count=2+len(rs)+len(weights);sink=count-1
        graph=[{} for _ in range(count)];cost=[{} for _ in range(count)]
        def edge(a,b,capacity,price):
            graph[a][b]=capacity;graph[b][a]=0;cost[a][b]=price;cost[b][a]=-price
        maximum=max(int(round(abs(w-r.gross_pc)/r.gross_pc*1000000)) for r in rs for w in weights)
        penalty=maximum*len(ps)+1
        for i,r in enumerate(rs):
            edge(0,1+i,r.pcs,0)
            for j,w in enumerate(weights):
                price=int(round(abs(w-r.gross_pc)/r.gross_pc*1000000))
                if abs(w-r.gross_pc)>weight_tolerance(r,options)+1e-9:price+=penalty
                edge(1+i,1+len(rs)+j,r.pcs,price)
        for j,w in enumerate(weights):edge(1+len(rs)+j,sink,len(classes[w]),0)
        potential=[0]*count;flow=0
        while flow<len(ps):
            distances=[math.inf]*count;distances[0]=0;parent=[None]*count;queue=[(0,0)]
            while queue:
                distance,a=heapq.heappop(queue)
                if distance!=distances[a]:continue
                for b,capacity in graph[a].items():
                    if capacity<=0:continue
                    next_distance=distance+cost[a][b]+potential[a]-potential[b]
                    if next_distance<distances[b]:
                        distances[b]=next_distance;parent[b]=a;heapq.heappush(queue,(next_distance,b))
            if parent[sink] is None:raise RuntimeError('자동배정 조합을 완성하지 못했습니다.')
            for i,distance in enumerate(distances):
                if distance<math.inf:potential[i]+=distance
            capacity=len(ps)-flow;b=sink
            while b:
                a=parent[b];capacity=min(capacity,graph[a][b]);b=a
            b=sink
            while b:
                a=parent[b];graph[a][b]-=capacity;graph[b][a]+=capacity;b=a
            flow+=capacity
        for j,w in enumerate(weights):
            node=1+len(rs)+j
            possible={r.mawb for i,r in enumerate(rs) if graph[node].get(1+i,0)>0}
            if len(possible)==1:
                reachable={node};queue=deque([node])
                while queue:
                    a=queue.popleft()
                    for b,capacity in graph[a].items():
                        if 0<b<sink and capacity>0 and cost[a][b]+potential[a]-potential[b]==0 and b not in reachable:reachable.add(b);queue.append(b)
                possible.update(r.mawb for i,r in enumerate(rs) if 1+i in reachable and graph[1+i].get(node,0)>0 and cost[1+i][node]+potential[1+i]-potential[node]==0)
            offset=0
            for i,r in enumerate(rs):
                quantity=graph[node].get(1+i,0)
                if not quantity:continue
                r.pkgs.extend(p.id for p in classes[w][offset:offset+quantity]);offset+=quantity
                outside=abs(w-r.gross_pc)>weight_tolerance(r,options)+1e-9
                if len(possible)>1 or outside:r.match_status='추정배정'
                if outside:r.match_note+='중량 오차범위 초과; '
                if len(possible)>1 and '동일 조건' not in r.match_note:r.match_note+='동일 조건 복수 AWB; '
        for r in rs:
            if len(r.pkgs)!=r.pcs:raise RuntimeError('자동배정 수량 검증 실패')
            if r.match_status!='추정배정':r.match_status='자동매칭'
            r.match_note+=weight_rule(options)+' / 중량 차이율 합계 최소, 동일 조건은 PKG 순서 배분'
            if r.match_status=='추정배정':r.candidate_pkgs=[p.id for p in ps]
            issues.append((r.match_status,r.sheet,r.row,r.mawb,', '.join(r.pkgs)+' / '+r.match_note))


def assign(packages, rows, issues, mode='legacy', settings=None):
    if mode not in MODE_LABELS:raise ValueError('지원하지 않는 배정 방식: '+str(mode))
    if mode=='auto':
        assign_auto(packages,rows,issues,settings)
        lookup={p.id:p for p in packages}
        for row in rows:
            gross=sum(num(lookup[pid].data[10],pid) for pid in row.pkgs)
            if abs(gross-row.gross_pc*row.pcs)>max(1,row.pcs):issues.append(('확인필요',row.sheet,row.row,row.mawb,f'CIPL G.W {gross:,.3f} / Pricing G.W {row.gross_pc*row.pcs:,.3f} 차이'))
        return lookup
    if mode=='explicit':
        for row in rows:
            if not row.explicit:raise ValueError(f'{row.sheet} {row.row}행: PKG NO.가 없습니다. PKG 지정 버전은 임의 배정하지 않습니다.')
            row.match_status='지정PKG';row.match_note='Pricing에 명시한 PKG 사용'
    lookup={p.id:p for p in packages}; used=set()
    for row in rows:
        if not row.explicit: continue
        if len(row.explicit)!=row.pcs: raise ValueError(f'{row.sheet} {row.row}행: PKG 개수와 PCS 불일치')
        for pid in row.explicit:
            if pid not in lookup: raise ValueError(f'CIPL에 없는 PKG: {pid}')
            p=lookup[pid]
            if pid in used: raise ValueError(f'PKG 중복배정: {pid}')
            if (p.task,p.dims)!=(row.task,row.dims): raise ValueError(f'PKG {pid}: TASK 또는 치수 불일치')
            used.add(pid); row.pkgs.append(pid)
    pools=defaultdict(list)
    for p in packages:
        if p.id not in used:pools[(p.task,p.dims)].append(p)
    for values in pools.values(): values.sort(key=lambda p:(0,int(p.id)) if p.id.isdigit() else (1,p.id))
    for row in rows:
        if row.pkgs: continue
        candidates=pools[(row.task,row.dims)]
        if len(candidates)<row.pcs:
            raise ValueError(f'{row.sheet} {row.row}행 {row.task} {row.dims}: {row.pcs}개 필요 / CIPL 미배정 {len(candidates)}개')
        row.pkgs=[p.id for p in candidates[:row.pcs]]
        del candidates[:row.pcs]
        used.update(row.pkgs)
        issues.append(('임의배정',row.sheet,row.row,row.mawb,','.join(row.pkgs)+' / TASK·치수 일치, PKG 오름차순'))
    unmatched=[p.id for p in packages if p.id not in used]
    if unmatched:raise ValueError('Pricing에 배정되지 않은 CIPL PKG: '+', '.join(unmatched))
    for row in rows:
        gross=sum(num(lookup[pid].data[10],pid) for pid in row.pkgs)
        if abs(gross-row.gross_pc*row.pcs)>max(1,row.pcs):
            issues.append(('확인필요',row.sheet,row.row,row.mawb,f'CIPL 포장 G.W {gross:,.3f} / Pricing G.W {row.gross_pc*row.pcs:,.3f} 차이. Packing은 CIPL, 스케쥴은 Pricing 사용'))
    return lookup

def validate_pkg_mirrors(book,rows):
    selected={r.sheet for r in rows}
    for row in rows:
        for sheet in selected-{row.sheet}:
            h=book.headers(sheet);pc=h.get('PKGNO.') or h.get('PKGNO') or h.get('PKG')
            if not pc:continue
            matches=[]
            for rr in sorted({int(re.search(r'\d+',a).group()) for a in book.cells[sheet]}):
                if rr<=1 or norm(book.value(sheet,f'{h["TASK"]}{rr}'))!=row.task:continue
                raw=book.value(sheet,f'{h["MAWB"]}{rr}')
                if raw is None or awb(raw)!=row.mawb:continue
                dims=tuple(integer(Decimal(str(book.value(sheet,f'{h[k]}{rr}')))*10,k) for k in ('L','W','H'))
                if dims==row.dims and integer(book.value(sheet,f'{h["PCS"]}{rr}'),'PCS')==row.pcs:matches.append(rr)
            if len(matches)==1:
                rr=matches[0];raw=book.value(sheet,f'{pc}{rr}')
                if raw is not None and not str(raw).upper().startswith('EX'):
                    ids=[p.strip() for p in re.split(r'[,，\n]+',identifier(raw)) if p.strip()]
                    if len(ids)!=len(row.pkgs) or set(ids)!=set(row.pkgs):raise ValueError(f'{sheet} {rr}행: 두 시트 PKG 불일치. 입력 번호를 확인하세요.')


def analyze(cipl, pricing, selections, mode='legacy', settings=None):
    cb,pb=Xlsx(cipl),Xlsx(pricing)
    if cb.path==pb.path: raise ValueError('CIPL과 Pricing은 서로 다른 파일이어야 합니다.')
    packages=read_packages(cb); tasks=sorted({p.task for p in packages}); issues=[]
    rows=read_pricing(pb,selections,tasks,issues,use_explicit=mode!='auto')
    lookup=assign(packages,rows,issues,mode,settings)
    if mode=='explicit':validate_pkg_mirrors(pb,rows)
    append_cache_notices((cb,pb),issues)
    return cb,pb,packages,rows,lookup,issues

def append_cache_notices(books,issues):
    for book in books:
        for sheet,address,formula in sorted(book.cached_formula_cells):
            notice=('확인필요',sheet,address,'',f'미지원 수식의 Excel 저장 계산값 사용: ={formula}. 원본을 Excel에서 재계산 후 저장하세요.')
            if notice not in issues:issues.append(notice)

def default_selections(cipl,pricing):
    cb,pb=Xlsx(cipl),Xlsx(pricing)
    tasks=sorted({p.task for p in read_packages(cb)})
    result={}
    for task in tasks:
        exact=[s for s in pb.sheets if norm(s)==f'스케{task}']
        names=[s for s in pb.sheets if task in s]
        result[task]=(exact or names or [''])[0]
    return result

@dataclass
class Formula:
    expression: str
    value: object

def setcell(row, column, value, style=None):
    address=f'{column}{row.get("r")}'
    c=next((c for c in row if c.get('r')==address),None)
    if c is None:
        c=ET.SubElement(row,tag('c'),{'r':address})
    saved_style=style if style is not None else c.get('s')
    c.attrib={'r':address}
    if saved_style is not None:c.set('s',str(saved_style))
    c[:]=[]
    if isinstance(value, Formula):
        ET.SubElement(c,tag('f')).text=value.expression.lstrip('=')
        if isinstance(value.value,str): c.set('t','str')
        ET.SubElement(c,tag('v')).text=str(value.value)
    elif isinstance(value,datetime):
        c.set('s',str(DATE_STYLE))
        ET.SubElement(c,tag('v')).text=str((value-datetime(1899,12,30)).total_seconds()/86400)
    elif isinstance(value,(int,float,Decimal)) and not isinstance(value,bool):
        ET.SubElement(c,tag('v')).text=str(value)
    elif value is not None:
        c.set('t','inlineStr')
        text=ET.SubElement(ET.SubElement(c,tag('is')),tag('t'))
        text.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
        text.text=str(value)
    return c

DATE_STYLE=0
class OutputBook:
    def __init__(self,template):
        global DATE_STYLE
        self.template=Xlsx(template); self.sheets=[]
        self.styles=ET.fromstring(self.template.parts['xl/styles.xml'])
        self.style_namespaces=namespace_map(self.template.parts['xl/styles.xml'])
        # A real numeric Excel date, with a portable display format.
        numfmts=self.styles.find(tag('numFmts'))
        if numfmts is None:
            numfmts=ET.Element(tag('numFmts'));self.styles.insert(0,numfmts)
        fmtid=max([163]+[int(x.get('numFmtId')) for x in numfmts])+1
        ET.SubElement(numfmts,tag('numFmt'),{'numFmtId':str(fmtid),'formatCode':'yyyy-mm-dd'})
        numfmts.set('count',str(len(numfmts)))
        xfs=self.styles.find(tag('cellXfs'))
        body_style=int(self.template.cells['스케쥴']['F3'].get('s','0'))
        xf=copy.deepcopy(xfs[body_style]);xf.set('numFmtId',str(fmtid));xf.set('applyNumberFormat','1')
        DATE_STYLE=len(xfs);xfs.append(xf);xfs.set('count',str(len(xfs)))
        self.text_style=len(xfs)
        xf=copy.deepcopy(xfs[body_style]);xf.set('numFmtId','0');xf.set('applyNumberFormat','1')
        alignment=xf.find(tag('alignment'))
        if alignment is None:alignment=ET.SubElement(xf,tag('alignment'))
        alignment.set('wrapText','1');alignment.set('vertical','center');alignment.set('horizontal','left')
        xfs.append(xf);xfs.set('count',str(len(xfs)))

    def sheet(self, template_name, name, entries, row_templates=None, merges=None, widths=None):
        source=self.template.sheets[template_name]
        ws=copy.deepcopy(source)
        for element in ws.iter():
            for attr in list(element.attrib):
                if attr.startswith('{') and not attr.startswith(('{'+NS+'}','{'+REL+'}','{http://www.w3.org/XML/1998/namespace}')):del element.attrib[attr]
        for setup in ws.iter(tag('pageSetup')):setup.attrib.pop(f'{{{REL}}}id',None)
        for child in list(ws):
            if child.tag in [tag(x) for x in ('sheetData','mergeCells','autoFilter','conditionalFormatting','dataValidations','hyperlinks','drawing','legacyDrawing','extLst','rowBreaks','colBreaks','tableParts','sheetProtection')]:ws.remove(child)
        data=ET.Element(tag('sheetData'))
        # sheetData must follow sheetFormatPr/cols, before page settings.
        insert=next((i for i,c in enumerate(ws) if c.tag in [tag(x) for x in ('sheetCalcPr','sheetProtection','printOptions','pageMargins','pageSetup','headerFooter')]),len(ws))
        ws.insert(insert,data)
        prototypes={int(r.get('r')):r for r in source.find(tag('sheetData'))}
        for r in sorted(entries):
            proto=(row_templates or {}).get(r,r)
            original=prototypes.get(proto,prototypes.get(6))
            rr=copy.deepcopy(original) if original is not None else ET.Element(tag('row'))
            rr.set('r',str(r)); rr.attrib.pop('spans',None)
            for c in rr:
                c.set('r',re.sub(r'\d+',str(r),c.get('r')))
                c[:]=[]; c.attrib.pop('t',None)
            for column,value in entries[r].items():setcell(rr,column,value)
            rr[:]=sorted(rr,key=lambda c:idx(re.match(r'[A-Z]+',c.get('r')).group()))
            data.append(rr)
        if merges:
            m=ET.Element(tag('mergeCells'),{'count':str(len(merges))})
            for ref in merges: ET.SubElement(m,tag('mergeCell'),{'ref':ref})
            ws.insert(list(ws).index(data)+1,m)
        if widths:
            cols=ws.find(tag('cols'))
            if cols is not None:ws.remove(cols)
            cols=ET.Element(tag('cols'))
            for i,w in enumerate(widths,1):ET.SubElement(cols,tag('col'),{'min':str(i),'max':str(i),'width':str(w),'customWidth':'1'})
            ws.insert(list(ws).index(data),cols)
        maxcol=max((idx(c) for row in entries.values() for c in row),default=1)
        dimension=ws.find(tag('dimension'))
        if dimension is not None:dimension.set('ref',f'A1:{col(maxcol)}{max(entries)}')
        for sel in ws.iter(tag('selection')):
            sel.set('activeCell','A1');sel.set('sqref','A1')
        order_worksheet(ws)
        self.sheets.append((name,ws))
        return ws

    def save(self,path):
        root=ET.Element(tag('workbook'),{f'{{{REL}}}dummy':''})
        root.attrib.clear()
        ET.SubElement(ET.SubElement(root,tag('bookViews')),tag('workbookView'),{'activeTab':'0'})
        sheets=ET.SubElement(root,tag('sheets'))
        rels=ET.Element(f'{{{PKGREL}}}Relationships')
        types=ET.Element(f'{{{CT}}}Types')
        for ext,typ in [('rels','application/vnd.openxmlformats-package.relationships+xml'),('xml','application/xml')]:
            ET.SubElement(types,f'{{{CT}}}Default',{'Extension':ext,'ContentType':typ})
        def override(part,typ):ET.SubElement(types,f'{{{CT}}}Override',{'PartName':'/'+part,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.'+typ+'+xml'})
        override('xl/workbook.xml','sheet.main');override('xl/styles.xml','styles')
        for i,(name,ws) in enumerate(self.sheets,1):
            ET.SubElement(sheets,tag('sheet'),{'name':name,'sheetId':str(i),f'{{{REL}}}id':f'rId{i}'})
            ET.SubElement(rels,f'{{{PKGREL}}}Relationship',{'Id':f'rId{i}','Type':REL+'/worksheet','Target':f'worksheets/sheet{i}.xml'})
            override(f'xl/worksheets/sheet{i}.xml','worksheet')
        ET.SubElement(rels,f'{{{PKGREL}}}Relationship',{'Id':'rIdStyles','Type':REL+'/styles','Target':'styles.xml'})
        ET.SubElement(root,tag('calcPr'),{'calcId':'191029','fullCalcOnLoad':'1'})
        package_rels=ET.Element(f'{{{PKGREL}}}Relationships')
        ET.SubElement(package_rels,f'{{{PKGREL}}}Relationship',{'Id':'rId1','Type':REL+'/officeDocument','Target':'xl/workbook.xml'})
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
            for part,obj in [('[Content_Types].xml',types),('_rels/.rels',package_rels),('xl/workbook.xml',root),('xl/_rels/workbook.xml.rels',rels),('xl/styles.xml',self.styles)]:
                z.writestr(part,serialize_xml(obj,self.style_namespaces if part=='xl/styles.xml' else None))
            for i,(_,ws) in enumerate(self.sheets,1):
                order_worksheet(ws)
                z.writestr(f'xl/worksheets/sheet{i}.xml',serialize_xml(ws))

def source_constants(book,sheet,rows):
    result={}
    for r in rows:
        result[r]={}
        for address,c in book.cells[sheet].items():
            if int(re.search(r'\d+',address).group())==r:
                if c.find(tag('f')) is None:
                    v=book.raw(c)
                    if v is not None:result[r][re.match(r'[A-Z]+',address).group()]=v
    return result

def quote(out,cb,groups,name,issues,settings,overview=False):
    s='견적조건 및 견적서'
    e=source_constants(out.template,s,list(range(2,10))+list(range(40,60)))
    # Current contacts and conditions come from the CIPL, not historical ANSWER data.
    first_task=groups[0]['rows'][0].task
    src=next((x for x in cb.sheets if x.endswith('_'+first_task)),None)
    if src:
        for r,c in [(4,'C'),(5,'C'),(6,'C'),(5,'M'),(6,'M')]:e.setdefault(r,{})[c]=cb.value(src,f'{c}{r}')
    mode=settings.get('matching_mode','legacy')
    status_note=' / PKG–AWB 확인필요 포함' if any(r.match_status=='확인필요' for g in groups for r in g['rows']) else ' / 추정배정 포함' if any(r.match_status=='추정배정' for g in groups for r in g['rows']) else ''
    e[1]={'B':MODE_LABELS[mode]+' / 원본 제공자료 기준'+status_note}
    e[8]['B']='LX판토스'+(' / 통합' if overview else f" / {groups[0]['mawb']}")
    rate_by_task={}
    for task in sorted({r.task for g in groups for r in g['rows']}):
        source=next((x for x in cb.sheets if x.endswith('_'+task)),None)
        if not source:raise ValueError(f'{task} 견적조건 및 견적서가 CIPL에 없습니다.')
        rate_by_task[task]={r:num(cb.value(source,f'I{r}'),f'{source}!I{r}') for r in (10,11,13,15,19)}
    fx=num(settings.get('exchange_rate',1450),'환율',True)
    e[7]={'H':'적용환율','I':fx if overview else Formula("'견적조건 및 견적서'!I7",fx),'J':'KRW/USD'}
    rows=[r for g in groups for r in g['rows']]
    cwt=sum(r.cwt for r in rows); count=len(groups)
    fees={key:sum(rate_by_task[g['rows'][0].task][key] for g in groups) for key in (10,15,19)}
    thc=sum(rate_by_task[r.task][11]*r.cwt for r in rows)
    air=sum(rate_by_task[r.task][13]*r.cwt for r in rows)
    domestic=fees[10]+thc
    for r,label,unit,currency,rate,quantity,total in [
        (10,'DOC','B/L','KRW',fees[10]/count,count,fees[10]),
        (11,'THC','C.W','KRW',thc/cwt,cwt,thc),
        (13,'AIR FREIGHT','C.W','KRW',air/cwt,cwt,air),
        (15,'AIR LINE TERMINAL FEE','All IN','USD',fees[15]/count,count,fees[15]),
        (20,'CUSTOM CLEARANCE','BL','USD',fees[19]/count,count,fees[19])]:
        e[r]={'E':label,'H':unit,'I':rate,'J':currency,'K':quantity,'L':Formula(f'I{r}*K{r}',total)}
    e[10]['B']='국내비용';e[13]['B']='항공운임';e[15]['B']='도착지 비용'
    if src:
        e[13]['M']=cb.value(src,'M13')
        e[20]['M']=cb.value(src,'M19')
    e[12]={'B':'국내비용 합계 (KRW)','L':Formula('SUM(L10:L11)',domestic)}
    e[14]={'B':'항공운임 합계 (USD)','L':Formula('L13/$I$7',air/fx)}
    for r,label in [(16,'53ft DRY VAN'),(17,'FLAT BED'),(18,'STEP DECK')]:
        e[r]={'E':'TRUCKING','H':'TRUCK','J':'USD','L':Formula(f'IF(AND(ISNUMBER(I{r}),ISNUMBER(K{r})),I{r}*K{r},"미입력")','미입력'),'M':label+' / 미사용 시 단가·대수 모두 0 입력'}
    e[19]={'E':'OTHER','J':'USD','K':1,'L':Formula('IF(ISNUMBER(I19),I19*K19,"미입력")','미입력'),'M':'기타비용 미발생 시 단가 0 입력'}
    e[21]={'B':'도착지비용 합계 (USD)','L':Formula('IF(COUNT(L15:L20)=6,SUM(L15:L20),"미확정")','미확정')}
    e[22]={'B':'TOTAL (KRW)','L':Formula('IF(ISNUMBER(L21),L12+L13+L21*$I$7,"미확정")','미확정')}
    e[23]={'B':'TOTAL (USD)','L':Formula('IF(ISNUMBER(L21),L12/$I$7+L14+L21,"미확정")','미확정'),'M':'환율: I7에서 변경'}
    e[24]={'B':None,'C':'ETD','F':'ETA','G':'ETA SITE','H':'AIRLINE','J':'T/S 여부','L':'비고 * 스케줄 기입 필수'}
    # Move the conditions before adding schedules that may occupy their old rows.
    n=max(15,len(groups)); shift=n-15
    if shift:
        for r in range(59,39,-1):e[r+shift]=e.pop(r)
    for i,g in enumerate(groups):
        r=25+i; item=g['rows'][0]
        e[r]={'C':item.etd,'F':None,'G':None,'H':item.airline,'J':None,'L':g['mawb']+' / ETA·T/S 미입력'}
    # Keep the reference's 15 schedule slots; extend them for larger shipments.
    for r in range(25+n,40+shift):e[r]={}
    prototypes={r:(r-shift if r>=40+shift else 25 if 25<=r<40+shift else r) for r in e}
    merges=[]
    for m in out.template.sheets[s].find(tag('mergeCells')):
        ref=m.get('ref')
        def move(match):
            c,r=match.groups();rr=int(r)
            return c+str(rr+shift if rr>=40 else rr)
        if shift:ref=re.sub(r'([A-Z]+)(\d+)',move,ref)
        if re.match(r'B24:B\d+',ref):ref=f'B24:B{24+n}'
        merges.append(ref)
    if shift:
        for r in range(40,40+shift):
            for a,b in [('C','E'),('H','I'),('J','K'),('L','M')]:merges.append(f'{a}{r}:{b}{r}')
    merges.append('B1:M1')
    ws=out.sheet(s,name,e,prototypes,merges)
    for rr in ws.find(tag('sheetData')):
        r=int(rr.get('r'))
        if r in (1,7):rr.set('ht','22');rr.set('customHeight','1')
    return domestic,air/fx,fees[15]+fees[19]

def total_quote(out,groups):
    # Copy the styled overview; read each split quotation exactly once.
    ws=copy.deepcopy(out.sheets[0][1])
    for rr in ws.find(tag('sheetData')):
        r=int(rr.get('r'))
        if r==1:setcell(rr,'B',f'총합 견적서 / 분할견적 {len(groups)}건 합산'+(' / 추정배정 포함' if any(item.match_status=='추정배정' for g in groups for item in g.get('rows',[])) else ''))
        if r==7:
            original=next(c for c in rr if c.get('r')=='I7')
            setcell(rr,'I',Formula("'견적조건 및 견적서'!I7",out.template.raw(original)))
        if r==8:setcell(rr,'B','LX판토스 / 총합')
        if r in (12,14,21,22,23):
            refs=','.join(f"'분할견적서_{g['number']}'!L{r}" for g in groups)
            original=next(c for c in rr if c.get('r')==f'L{r}')
            setcell(rr,'L',Formula(f'IF(COUNT({refs})={len(groups)},SUM({refs}),"미확정")',out.template.raw(original)))
        if r==23:setcell(rr,'M','환율: 견적조건 및 견적서 I7')
    position=next(i for i,(name,_) in enumerate(out.sheets) if name.startswith('분할견적서_'))
    out.sheets.insert(position,('총합 견적서',ws))


def build_answer(cb,pb,packages,rows,lookup,issues,template,settings):
    out=OutputBook(template)
    groups=[]; by_awb={}
    for row in rows:
        if row.mawb not in by_awb:
            by_awb[row.mawb]={'mawb':row.mawb,'rows':[],'number':len(groups)+1};groups.append(by_awb[row.mawb])
        by_awb[row.mawb]['rows'].append(row)
    for g in groups:
        if len({r.task for r in g['rows']})>1:raise ValueError(f"{g['mawb']}: 서로 다른 TASK가 같은 AWB입니다. 서류분할 기준 확인 필요")
        if len({(str(r.received),str(r.etd),r.skd) for r in g['rows']})>1:issues.append(('확인필요','Pricing',0,g['mawb'],'동일 AWB 내 입고일/스케줄 차이. 첫 행을 스케쥴 대표행으로 사용'))
    quote(out,cb,groups,'견적조건 및 견적서',issues,settings,True)
    totals={}
    for g in groups:totals[g['mawb']]=None
    tracking={2:{col(i):v for i,v in enumerate(['서류번호','CI NO.','입고일','ONBOARD DATE','CARRIER','SCHEDULE','MAWB NO','HAWB NO','POL','POD','PKG','G.WT','C.WT','배송지','배송상태','배송예정일','POD','(개별) 항공운임 + 도착지비용 (USD)','(개별) 국내비용 (KRW)','관부가세 (USD)'],2)}}
    packing={1:{'A':'DETAILED PACKING LIST'},3:{'A':'NAME OF SUPPLY CONTRACT : '+identifier(cb.value('PL Attachment','E3'))},5:source_constants(out.template,'Packing List_스케줄',[5])[5]}
    if settings.get('matching_mode')=='auto':packing[5]['W']='PKG–AWB 연결 상태'
    owners={pid:(r,by_awb[r.mawb]['number']) for r in rows for pid in r.pkgs}
    i=6
    for p in packages:
        v=p.data; shipment,no=owners[p.id]
        flight=re.search(r'(?:^|\s)([A-Z0-9]{2}\d{2,4}(?:~\d{2,4})?)(?=\s|$|/)',shipment.skd)
        entry={'A':p.id,'B':v[2],'C':p.task,'D':v[5],'E':v[6],'F':v[7],'G':v[8],'H':v[9],'I':v[10],
            'J':v[11],'K':'X','L':v[13],'M':'X','N':v[15],'O':Formula(f'J{i}*L{i}*N{i}/1000000000',v[16]),
            'P':v[19],'Q':shipment.received,'R':no,'S':flight.group(1) if flight else shipment.skd,'T':shipment.mawb,'U':shipment.etd,'V':None}
        pending=shipment.match_status=='확인필요'
        if pending:
            entry.update({c:None for c in ('Q','R','S','T','U')})
            entry['W']='PKG–AWB 확인필요'
        elif settings.get('matching_mode')=='auto':entry['W']='추정배정' if shipment.match_status=='추정배정' else '단일 AWB 구분' if '중량 조건 불일치' in shipment.match_note else '자동매칭'
        packing[i]=entry
        i+=1
        for d in p.details:
            packing[i]={'A':None,'C':p.task,'E':d[6],'F':d[7],'G':d[8],'H':d[9],'I':d[10],
                'J':d[11],'L':d[13],'N':d[15],'O':d[16],'R':None if pending else no,'T':None if pending else shipment.mawb}
            if pending:packing[i]['W']='PKG–AWB 확인필요'
            elif shipment.match_status=='추정배정':packing[i]['W']='추정배정'
            i+=1
    last=i
    packing[last]={'E':'TOTAL'}
    for column,source in [('F',7),('H',9),('I',10),('O',16)]:
        packing[last][column]=Formula(f'SUMIFS({column}6:{column}{last-1},A6:A{last-1},"<>")',sum(p.data[source] for p in packages))
    for i,g in enumerate(groups,3):
        r=g['rows'][0]
        tr={'B':g['number'],'C':None,'D':r.received,'E':r.etd,'F':r.airline,'G':r.skd,'H':r.mawb,'I':None,
            'J':'ICN','K':r.dest,'L':sum(x.pcs for x in g['rows']),'M':sum(x.gross_pc*x.pcs for x in g['rows']),
            'N':sum(x.cwt for x in g['rows']),'O':None,'P':'ETA·현지비용 미입력','Q':None,'R':None,'S':'미확정','T':None,'U':None}
        if any(x.match_status=='확인필요' for x in g['rows']):tr['P']='PKG–AWB 확인필요 / ETA·현지비용 미입력'
        elif any(x.match_status=='추정배정' for x in g['rows']):tr['P']='추정배정 / ETA·현지비용 미입력'
        tracking[i]=tr
    totalrow=3+len(groups)
    tracking[totalrow]={c:Formula(f'SUM({c}3:{c}{totalrow-1})',sum(tracking[r][c] for r in range(3,totalrow))) for c in ('L','M','N')}
    tracking[totalrow]['S']='미확정'
    out.sheet('스케쥴','스케쥴',tracking,{r:2 if r==2 else 3 if r<totalrow else 25 for r in tracking})
    packing_ws=out.sheet('Packing List_스케줄','Packing List_스케줄',packing,{r:6 if 6<=r<last else 175 if r==last else r for r in packing},['A1:O2','A3:O3','J5:N5'])
    if settings.get('matching_mode')=='auto':
        cols=packing_ws.find(tag('cols'))
        for column in list(cols):
            a,b=int(column.get('min')),int(column.get('max'))
            if a<=23<=b:
                if b>23:
                    tail=copy.deepcopy(column);tail.set('min','24');cols.append(tail)
                if a<23:column.set('max','22')
                else:cols.remove(column)
        ET.SubElement(cols,tag('col'),{'min':'23','max':'23','width':'28','customWidth':'1'})
        cols[:]=sorted(cols,key=lambda c:int(c.get('min')))
        for rr in packing_ws.find(tag('sheetData')):
            cell=next((c for c in rr if c.get('r')==f'W{rr.get("r")}'),None)
            if cell is not None:cell.set('s',str(out.text_style))
    # Requested tab order: summary -> tracking -> packing -> per-AWB quotations.
    for g in groups:
        domestic,air,local_known=quote(out,cb,[g],f"분할견적서_{g['number']}",issues,settings)
        prefix=f"'분할견적서_{g['number']}'!"
        tr=tracking[2+g['number']]
        tr['T']=Formula(prefix+'L12',domestic)
        tr['S']=Formula(f'IF(ISNUMBER({prefix}L21),{prefix}L14+{prefix}L21,"미확정")','미확정')
    # Tracking's numeric domestic costs are independent of unknown destination fees.
    trackdata=out.sheets[1][1].find(tag('sheetData'))
    for rr in trackdata:
        r=int(rr.get('r'))
        if 3<=r<totalrow:
            setcell(rr,'T',tracking[r]['T']);setcell(rr,'S',tracking[r]['S'])
        if r==totalrow:
            setcell(rr,'T',Formula(f'SUM(T3:T{totalrow-1})',sum(tracking[r]['T'].value for r in range(3,totalrow))))
            setcell(rr,'S',Formula(f'IF(COUNT(S3:S{totalrow-1})={len(groups)},SUM(S3:S{totalrow-1}),"미확정")','미확정'))
    # The overview reads editable detail quotations; destination cost is entered only once.
    summary=out.sheets[0][1].find(tag('sheetData'))
    for rr in summary:
        r=int(rr.get('r'))
        if r in (10,11,13,15,16,17,18,19,20):
            refs=','.join(f"'분할견적서_{g['number']}'!L{r}" for g in groups)
            counts=','.join(f"'분할견적서_{g['number']}'!K{r}" for g in groups)
            def cached(column,default):
                c=next((x for x in rr if x.get('r')==f'{column}{r}'),None)
                return out.template.raw(c) if c is not None and c.find(tag('v')) is not None else default
            known=r in (10,11,13,15,20)
            quantity=cached('K',0) if known else len(groups) if r==19 else 0
            amount=cached('L','미입력') if known else '미입력'
            rate=cached('I','미입력') if known else '미입력'
            setcell(rr,'K',Formula(f'SUM({counts})',quantity))
            setcell(rr,'L',Formula(f'IF(COUNT({refs})={len(groups)},SUM({refs}),"미입력")',amount))
            setcell(rr,'I',Formula(f'IF(ISNUMBER(L{r}),IF(K{r}=0,0,L{r}/K{r}),"미입력")',rate))
            if not known:setcell(rr,'M','분할견적서에서 단가·대수 입력')
    total_quote(out,groups)
    review={1:{'A':'구분','B':'시트','C':'행','D':'MAWB','E':'확인사항'}}
    append_cache_notices((cb,pb),issues)
    items=list(issues)+[('미입력','전체',0,'','ETA·ETA SITE·T/S·현지 트럭 단가/대수·기타비용·CI/HAWB·배송주소·관부가세는 입력 원본에 없어 미확정')]
    for i,item in enumerate(items,2):review[i]={col(j):v for j,v in enumerate(item,1)}
    review_ws=out.sheet('스케쥴','검토사항',review,{r:2 if r==1 else 3 for r in review},widths=[14,28,8,19,100])
    for rr in review_ws.find(tag('sheetData')):
        rr.set('ht','44');rr.set('customHeight','1')
        for c in rr:
            if int(rr.get('r'))>1 or c.get('r')=='A1':c.set('s',str(out.text_style))
    return out,groups

def save_pricing(pb,rows,path,issues=None):
    roots={s:copy.deepcopy(r) for s,r in pb.sheets.items()}
    edits=[]
    issues=issues if issues is not None else []
    selected_sheets={x.sheet for x in rows}
    source_groups=defaultdict(list)
    for item in rows:
        h=pb.headers(item.sheet)
        pc=h.get('PKGNO.') or h.get('PKGNO') or h.get('PKG')
        if not pc:
            pc=col(max(idx(c) for c in h.values())+1)
        edits.append((item.sheet,1,pc,'PKG NO.'))
        edits.append((item.sheet,item.row,pc,', '.join(item.pkgs)))
        source_groups[(item.task,item.sheet,item.mawb,item.dims,item.pcs)].append(item)
    # A source row must map to exactly one target row, including its PCS.
    for (task,source_sheet,mawb,dims,pcs),sources in source_groups.items():
        for other in selected_sheets-{source_sheet}:
            oh=pb.headers(other)
            opc=oh.get('PKGNO.') or oh.get('PKGNO') or oh.get('PKG')
            if not opc:continue
            candidates=[];related=[]
            for r in sorted({int(re.search(r'\d+',a).group()) for a in pb.cells[other]}):
                if r<=1 or norm(pb.value(other,f'{oh["TASK"]}{r}'))!=task:continue
                raw=pb.value(other,f'{oh["MAWB"]}{r}')
                if raw is None or awb(raw)!=mawb:continue
                target_dims=tuple(integer(Decimal(str(pb.value(other,f'{oh[k]}{r}')))*10,k) for k in ('L','W','H'))
                target_pcs=integer(pb.value(other,f'{oh["PCS"]}{r}'),f'{other} PCS{r}')
                if target_dims==dims:related.append(r)
                if (target_dims,target_pcs)==(dims,pcs):candidates.append(r)
            if len(sources)==1 and len(candidates)==1:
                item=sources[0];r=candidates[0]
                edits.extend([(other,1,opc,'PKG NO.'),(other,r,opc,', '.join(item.pkgs))])
            elif related:
                issues.append(('확인필요',other,','.join(map(str,related)),mawb,'PKG 동기화 생략: 동일 TASK·MAWB·치수·수량의 행 대응이 모호하거나 수량이 다릅니다. 기존값을 유지합니다.'))
    for s,r,c,v in edits:
        data=roots[s].find(tag('sheetData'));rr=next((x for x in data if int(x.get('r'))==r),None)
        if rr is None:rr=ET.SubElement(data,tag('row'),{'r':str(r)})
        setcell(rr,c,v)
        rr[:]=sorted(rr,key=lambda x:idx(re.match(r'[A-Z]+',x.get('r')).group()))
        dim=roots[s].find(tag('dimension'))
        if dim is not None:
            addresses=[c.get('r') for c in roots[s].iter(tag('c'))]
            dim.set('ref',f'A1:{col(max(idx(re.match(r"[A-Z]+",a).group()) for a in addresses))}{max(int(re.search(r"\d+",a).group()) for a in addresses)}')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        changed={pb.sheetpaths[s]:serialize_xml(root,namespace_map(pb.parts[pb.sheetpaths[s]])) for s,root in roots.items() if any(e[0]==s for e in edits)}
        for name,content in pb.parts.items():z.writestr(name,changed.get(name,content))

def run(cipl,pricing,output,selections,template=None,settings=None):
    settings=dict(settings or {})
    mode=settings.get('matching_mode','legacy')
    if mode not in MODE_LABELS:raise ValueError('지원하지 않는 배정 방식: '+str(mode))
    if mode=='auto':settings.update(auto_options(settings))
    target=Path(output).resolve()
    cb,pb,packages,rows,lookup,issues=analyze(cipl,pricing,selections,mode,settings)
    before={str(p):hash_file(p) for p in (cb.path,pb.path)}
    template=Path(template) if template else Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/'answer_template.xlsx'
    if not template.is_file():raise ValueError('answer_template.xlsx 양식이 프로그램 옆에 없습니다.')
    target.mkdir(parents=True,exist_ok=True)
    # A new folder per run avoids replacement of inputs, previous outputs, or files open in Excel.
    folder=Path(tempfile.mkdtemp(prefix=datetime.now().strftime('LS_%Y%m%d_%H%M%S_'),dir=target))
    try:
        answer_tmp=folder/'._ANSWER_작성중.xlsx'
        pricing_tmp=folder/'._Pricing_작성중.xlsx'
        if mode=='auto':pricing_tmp.write_bytes(pb.path.read_bytes())
        else:save_pricing(pb,rows,pricing_tmp,issues)
        out,groups=build_answer(cb,pb,packages,rows,lookup,issues,template,settings)
        out.save(answer_tmp)
        append_cache_notices((cb,pb),issues)
        validate_excel_structure(answer_tmp)
        validate_excel_structure(pricing_tmp)
        pending=sum(r.pcs for r in rows if r.match_status=='확인필요')
        estimated=sum(r.pcs for r in rows if r.match_status=='추정배정')
        assignments=[dict(vars(r),pkgs=[] if r.match_status=='확인필요' else r.pkgs) for r in rows]
        manifest={'status':'PKG–AWB 확인필요' if pending else '추정배정 포함' if estimated else '검토용 초안','program_version':APP_VERSION,'matching_mode':mode,'selections':selections,'source_sha256':before,'settings':settings,
            'packages':len(packages),'awbs':len(groups),'assigned_packages':len(packages)-pending,'confirmed_packages':len(packages)-pending-estimated,'estimated_packages':estimated,'pending_packages':pending,'assignments':assignments,'issues':issues}
        text=['검토용 ANSWER 생성 결과',f'PKG {len(packages)}개 / MAWB {len(groups)}건',
            MODE_LABELS[mode],
            f'PKG–AWB 연결: {len(packages)-pending}개 배정(추정 {estimated}개 포함) / {pending}개 미배정. 추정배정은 실제 출고 정보와 대조하세요.',
            ('자동분할: '+weight_rule(settings)+' / 추정 포함 배정 '+str(settings['auto_assign_estimates'])) if mode=='auto' else 'Pricing에 입력한 PKG를 검증합니다.' if mode=='explicit' else '임의 PKG는 TASK·치수·번호순으로 배정했습니다.',
            '각 분할견적서의 I16:I19 단가 및 K16:K18 대수를 입력하면 총액과 통합표·스케쥴 비용이 계산됩니다.',
            '총합 견적서는 분할견적서_1 바로 앞에 있으며 모든 분할견적의 항목별 금액과 총액을 합산합니다.',
            '미사용 차량도 단가·대수에 0을 명시하세요. 환율은 통합 견적서 I7에서 변경합니다.',
            'ETA·T/S·현지비용 미입력: 고객 제출 전 보완해야 합니다.',
            'G.W는 스케쥴에 Pricing, Packing에 CIPL 원본 포장중량을 사용합니다.']
        text += [' / '.join(map(str,x)) for x in issues]
        for path,digest in before.items():
            if hash_file(path)!=digest:raise RuntimeError('처리 중 원본 파일이 변경됐습니다. 결과 사용 전 재실행하세요.')
        check=Xlsx(answer_tmp)
        if len(check.sheets)!=5+len(groups):raise RuntimeError('출력 시트 검증 실패')
        names=list(check.sheets)
        if names.index('총합 견적서')+1!=names.index('분할견적서_1'):raise RuntimeError('총합 견적서 위치 검증 실패')
        Xlsx(pricing_tmp)
        answer_tmp.replace(folder/'ANSWER_검토용.xlsx')
        pricing_tmp.replace(folder/('Pricing_원본사본.xlsx' if mode=='auto' else 'Pricing_PKG배정.xlsx'))
        (folder/'배정근거.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        (folder/'검토로그.txt').write_text('\n'.join(text),encoding='utf-8-sig')
        return folder,manifest
    except Exception:
        (folder/'실패로그.txt').write_text(__import__('traceback').format_exc(),encoding='utf-8-sig')
        # Incomplete workbooks must never look like a successful deliverable.
        for name in ('ANSWER_검토용.xlsx','Pricing_PKG배정.xlsx','Pricing_원본사본.xlsx','._ANSWER_작성중.xlsx','._Pricing_작성중.xlsx'):
            p=folder/name
            if p.is_file():p.unlink()
        raise

def gui(mode='auto'):
    import tkinter as tk
    from tkinter import ttk,filedialog,messagebox
    root=tk.Tk();root.title(f'LS ANSWER / {MODE_LABELS[mode]} / v{APP_VERSION}');root.geometry('930x740');root.minsize(820,700)
    frame=ttk.Frame(root,padding=22);frame.pack(fill='both',expand=True);frame.columnconfigure(1,weight=1)
    ttk.Label(frame,text='LS ANSWER 자동 생성',font=('맑은 고딕',18,'bold')).grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,12))
    ttk.Label(frame,text=MODE_LABELS[mode]+' / 두 Pricing 시트를 함께 사용합니다.').grid(row=1,column=0,columnspan=3,sticky='w',pady=(0,12))
    variables={key:tk.StringVar() for key in ('cipl','pricing','output')}
    variables['output'].set(str(Path.home()/'Documents'/'LS_ANSWER_결과'))
    combos={};task_frame=ttk.LabelFrame(frame,text='TASK별 적용 시트',padding=10)
    def browse(key):
        p=filedialog.askdirectory(title='결과 저장 폴더') if key=='output' else filedialog.askopenfilename(title='CIPL 선택' if key=='cipl' else 'Pricing 선택',filetypes=[('Excel 통합문서','*.xlsx')])
        if p:variables[key].set(p)
    for r,(key,label) in enumerate([('cipl','① CIPL 원본'),('pricing','② Pricing 원본'),('output','③ 결과 폴더')],2):
        ttk.Label(frame,text=label).grid(row=r,column=0,sticky='w',pady=5)
        ttk.Entry(frame,textvariable=variables[key]).grid(row=r,column=1,sticky='ew',padx=10)
        ttk.Button(frame,text='찾아보기',command=lambda k=key:browse(k)).grid(row=r,column=2)
    def load():
        try:
            choices=default_selections(variables['cipl'].get(),variables['pricing'].get())
            names=list(Xlsx(variables['pricing'].get()).sheets)
            for w in task_frame.winfo_children():w.destroy()
            combos.clear()
            for i,(task,s) in enumerate(choices.items()):
                ttk.Label(task_frame,text=task).grid(row=i,column=0,sticky='w',padx=5)
                v=tk.StringVar(value=s);combos[task]=v
                ttk.Combobox(task_frame,values=names,textvariable=v,state='readonly',width=43).grid(row=i,column=1,sticky='ew',pady=3)
            status.set('두 시트의 적용 TASK를 확인한 뒤 생성하세요.')
        except Exception as exc:
            logging.exception('입력 파일 분석 실패')
            messagebox.showerror('파일 확인',str(exc))
    ttk.Button(frame,text='파일 분석 / 시트 불러오기',command=load).grid(row=5,column=1,sticky='w',padx=10,pady=10)
    task_frame.grid(row=6,column=0,columnspan=3,sticky='ew');task_frame.columnconfigure(1,weight=1)
    fx=tk.StringVar(value='1450')
    ttk.Label(frame,text='적용환율 KRW/USD').grid(row=7,column=0,sticky='w',pady=12)
    ttk.Entry(frame,textvariable=fx,width=15).grid(row=7,column=1,sticky='w',padx=10)
    tolerance_kg=tk.StringVar(value=str(DEFAULT_AUTO['weight_tolerance_kg']))
    tolerance_pct=tk.StringVar(value=str(DEFAULT_AUTO['weight_tolerance_percent']))
    estimates=tk.BooleanVar(value=DEFAULT_AUTO['auto_assign_estimates'])
    if mode=='auto':
        options_frame=ttk.LabelFrame(frame,text='자동배정 범위',padding=8)
        options_frame.grid(row=8,column=0,columnspan=3,sticky='ew',pady=4)
        ttk.Label(options_frame,text='중량 오차 (%)').grid(row=0,column=0,padx=5)
        ttk.Entry(options_frame,textvariable=tolerance_pct,width=9).grid(row=0,column=1)
        ttk.Label(options_frame,text='또는 (kg)').grid(row=0,column=2,padx=5)
        ttk.Entry(options_frame,textvariable=tolerance_kg,width=9).grid(row=0,column=3)
        ttk.Label(options_frame,text='중 큰 범위 적용').grid(row=0,column=4,padx=5)
        ttk.Checkbutton(options_frame,text='추정 포함 전량 배정 (동일 조건·오차 초과도 가까운 중량 순으로 배정)',variable=estimates).grid(row=1,column=0,columnspan=5,sticky='w',pady=5)
    help_text='Pricing PKG 번호 없이 TASK·사이즈·수량을 맞추고 중량이 가까운 조합부터 배정합니다.\n입력된 PKG 번호는 사용하지 않습니다. 동일 조건이나 오차 초과는 추정배정으로 표시하며, 추정 배정을 끄면 모호한 연결은 비워둡니다.' if mode=='auto' else 'Pricing에 적힌 PKG NO.를 사용합니다. 빈 번호·중복·수량·TASK·치수 불일치가 있으면 중단합니다.\n번호를 임의 배정하지 않습니다. 중량 차이는 검토사항에 표시합니다.'
    ttk.Label(frame,text=help_text+'\n원본 파일은 수정하지 않습니다.',wraplength=850).grid(row=9,column=0,columnspan=3,sticky='w',pady=8)
    status=tk.StringVar(value='원본 두 파일을 선택해 주세요.')
    ttk.Label(frame,textvariable=status,wraplength=850).grid(row=11,column=0,columnspan=3,sticky='w',pady=12)
    def generate():
        if not combos:load()
        if not combos:return
        selections={t:v.get() for t,v in combos.items()}
        paths={k:v.get() for k,v in variables.items()}
        try:
            rate=num(fx.get(),'환율',True)
            settings={'exchange_rate':rate,'matching_mode':mode}
            if mode=='auto':settings.update(auto_options({'weight_tolerance_kg':tolerance_kg.get(),'weight_tolerance_percent':tolerance_pct.get(),'auto_assign_estimates':estimates.get()}))
        except ValueError as exc:messagebox.showerror('입력 확인',str(exc));return
        button.state(['disabled']);status.set('PKG 대조 및 ANSWER 생성 중…')
        def complete(result=None,error=None):
            button.state(['!disabled'])
            if error:
                status.set('생성 실패: '+str(error));messagebox.showerror('생성 실패',str(error));return
            folder,manifest=result
            status.set(f"완료: {manifest['assigned_packages']}/{manifest['packages']}개 배정 / 추정 {manifest['estimated_packages']}개 / 미배정 {manifest['pending_packages']}개 / {folder}")
            messagebox.showinfo('생성 완료',f"저장 위치:\n{folder}\n\n배정: {manifest['assigned_packages']}개 (추정 {manifest['estimated_packages']}개 포함)\n미배정: {manifest['pending_packages']}개\n추정배정 내역은 검토사항과 로그를 확인하세요.")
            os.startfile(folder)
        def worker():
            try:result=run(paths['cipl'],paths['pricing'],paths['output'],selections,settings=settings)
            except Exception as exc:
                logging.exception('ANSWER 생성 실패')
                root.after(0,lambda e=exc:complete(error=e))
            else:root.after(0,lambda:complete(result=result))
        threading.Thread(target=worker,daemon=True).start()
    button=ttk.Button(frame,text=MODE_LABELS[mode]+' + ANSWER 생성',command=generate);button.grid(row=10,column=0,columnspan=3,sticky='ew',pady=10)
    root.mainloop()

def main(mode='auto'):
    if len(sys.argv)==1:gui(mode);return
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version',action='version',version=APP_VERSION)
    p.add_argument('--cipl',required=True);p.add_argument('--pricing',required=True);p.add_argument('--output',required=True)
    p.add_argument('--sheet',action='append',default=[],help='TASK=시트명. TASK별 반복 지정')
    p.add_argument('--template');p.add_argument('--exchange-rate',type=float,default=1450)
    p.add_argument('--weight-tolerance-kg',type=float,default=DEFAULT_AUTO['weight_tolerance_kg'])
    p.add_argument('--weight-tolerance-percent',type=float,default=DEFAULT_AUTO['weight_tolerance_percent'])
    p.add_argument('--strict-auto',action='store_true',help='자동 모드에서 추정 배정을 끄고 모호한 연결을 비워둠')
    args=p.parse_args()
    choices=default_selections(args.cipl,args.pricing)
    choices.update(dict(s.split('=',1) for s in args.sheet))
    settings={'exchange_rate':args.exchange_rate,'matching_mode':mode,'weight_tolerance_kg':args.weight_tolerance_kg,'weight_tolerance_percent':args.weight_tolerance_percent,'auto_assign_estimates':not args.strict_auto}
    folder,manifest=run(args.cipl,args.pricing,args.output,choices,args.template,settings)
    print(json.dumps({'folder':str(folder),'packages':manifest['packages'],'awbs':manifest['awbs'],'matching_mode':mode,'assigned_packages':manifest['assigned_packages'],'estimated_packages':manifest['estimated_packages'],'pending_packages':manifest['pending_packages']},ensure_ascii=False))

def entrypoint(mode='auto'):
    logdir=Path(os.environ.get('LOCALAPPDATA',tempfile.gettempdir()))/'LS_ANSWER'/'logs'
    logdir.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(filename=logdir/'application.log',encoding='utf-8',level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s')
    logging.info('프로그램 시작: version=%s matching_mode=%s',APP_VERSION,mode)
    try:main(mode)
    except Exception as exc:
        logging.exception('생성 실패')
        if len(sys.argv)==1:
            from tkinter import messagebox
            messagebox.showerror('프로그램 오류',str(exc))
        sys.exit(1)

if __name__=='__main__':entrypoint('auto')
