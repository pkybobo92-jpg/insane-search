@echo off
setlocal
cd /d "%~dp0"
set "LS_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%LS_PYTHON%" goto codex_python
where py >nul 2>nul
if not errorlevel 1 goto system_python
echo Python 3.12 or newer with tkinter is required for source execution.
echo The packaged EXE is standalone. If application control blocks it, contact your administrator.
pause
exit /b 1
:codex_python
"%LS_PYTHON%" "%~dp0answer_auto.py" %*
set "LS_EXIT=%ERRORLEVEL%"
goto done
:system_python
py -3 "%~dp0answer_auto.py" %*
set "LS_EXIT=%ERRORLEVEL%"
:done
if not "%LS_EXIT%"=="0" pause
exit /b %LS_EXIT%
