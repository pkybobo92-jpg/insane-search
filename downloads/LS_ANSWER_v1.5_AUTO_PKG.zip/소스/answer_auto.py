from answer_app import entrypoint

if __name__=='__main__':entrypoint('auto')
