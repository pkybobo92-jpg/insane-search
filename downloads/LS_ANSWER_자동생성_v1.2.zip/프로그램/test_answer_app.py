"""Run: python -m unittest discover -s . -v (sample input folder via LS_SAMPLE_DIR)."""
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from collections import Counter
from xml.etree import ElementTree as ET
import answer_app as app

BASE=Path(os.environ.get('LS_SAMPLE_DIR',''))
HAS_SAMPLES=bool(os.environ.get('LS_SAMPLE_DIR')) and BASE.is_dir()

def mutate(source,target,sheet,address,value):
    wb=app.Xlsx(source);root=wb.sheets[sheet]
    row=next(r for r in root.find(app.tag('sheetData')) if r.get('r')==''.join(filter(str.isdigit,address)))
    app.setcell(row,''.join(filter(str.isalpha,address)),value)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in wb.parts.items():
            z.writestr(name,app.serialize_xml(root,app.namespace_map(data)) if name==wb.sheetpaths[sheet] else data)

class UnitTests(unittest.TestCase):
    def test_awb_normalization(self):
        self.assertEqual(app.awb(' 027-20111512 '),'02720111512')
        self.assertEqual(app.awb(2720111512),'02720111512')
    def test_invalid_awb(self):
        for v in ('ABC','1','123456789012',None):
            with self.assertRaises(ValueError):app.awb(v)
    def test_column_numbers(self):
        for n in (1,14,26,27,31,52,702):self.assertEqual(app.idx(app.col(n)),n)
    def test_numeric_guards(self):
        for v in ('nan','inf',None,True):
            with self.assertRaises(ValueError):app.num(v,'test')
        for v in (0,-1,1.2):
            with self.assertRaises(ValueError):app.integer(v,'test')
        self.assertEqual(app.integer('1,000','test'),1000)
    def test_markup_prefixes_need_real_declarations(self):
        invalid=b'<x xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="xr"/>'
        with self.assertRaisesRegex(ValueError,'xr'):app.validate_markup_namespaces(invalid)
    def test_mc_only_namespace_survives_serialization(self):
        root=ET.Element(app.tag('worksheet'),{'{'+app.MC+'}Ignorable':'x14ac xr xr2 xr3'})
        data=app.serialize_xml(root)
        declared=app.namespace_map(data)
        for prefix in ('x14ac','xr','xr2','xr3'):self.assertIn(prefix,declared)
    def test_undeclared_mc_value_rejected(self):
        root=ET.Element(app.tag('worksheet'),{'{'+app.MC+'}Ignorable':'undefined_vendor'})
        with self.assertRaisesRegex(ValueError,'undefined_vendor'):app.serialize_xml(root)

@unittest.skipUnless(HAS_SAMPLES,'LS_SAMPLE_DIR에 제공 샘플 폴더 지정 필요')
class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cipl=next(BASE.glob('(*.xlsx'))
        cls.pricing=BASE/'Pricing 팀 제공파일.xlsx'
        cls.template=Path(__file__).parent/'answer_template.xlsx'
        cls.selections={'T124':'스케T124 126 127','T125':'스케T125'}
        cls.temp=tempfile.TemporaryDirectory()
        cls.target=Path(cls.temp.name)
        cls.result,cls.manifest=app.run(cls.cipl,cls.pricing,cls.target,cls.selections,cls.template)
        cls.wb=app.Xlsx(cls.result/'ANSWER_검토용.xlsx')
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_default_both_sheets(self):
        self.assertEqual(app.default_selections(self.cipl,self.pricing),self.selections)
    def test_header_collision(self):
        self.assertEqual(app.Xlsx(self.pricing).headers('스케T124 126 127')['H'],'Q')
    def test_packages_and_awbs(self):
        self.assertEqual((self.manifest['packages'],self.manifest['awbs']),(58,12))
        ids=[x for r in self.manifest['assignments'] for x in r['pkgs']]
        self.assertEqual(len(ids),len(set(ids)))
        totals=Counter()
        for r in self.manifest['assignments']:totals[r['task']]+=r['pcs']
        self.assertEqual(totals,{'T124':29,'T125':29})
    def test_expected_allocations(self):
        rows=self.manifest['assignments']
        self.assertEqual(next(r['pkgs'] for r in rows if r['mawb']=='27276223534'),['1','17'])
        self.assertEqual(next(r['pkgs'] for r in rows if r['mawb']=='27276222812'),['50','66'])
    def test_source_unchanged(self):
        for p,digest in self.manifest['source_sha256'].items():self.assertEqual(app.hash_file(p),digest)
    def test_output_sheet_structure(self):
        self.assertEqual(len(self.wb.sheets),16)
        self.assertEqual(list(self.wb.sheets)[:3],['견적조건 및 견적서','스케쥴','Packing List_스케줄'])
        self.assertIn('분할견적서_12',self.wb.sheets)
    def test_independent_control_totals(self):
        self.assertEqual(self.wb.value('스케쥴','L15'),58)
        self.assertAlmostEqual(self.wb.value('스케쥴','N15'),194160)
        self.assertAlmostEqual(self.wb.value('견적조건 및 견적서','L12'),4437360)
        # 97,080 chargeable kg per TASK with separate CIPL selling rates.
        self.assertAlmostEqual(self.wb.value('견적조건 및 견적서','L13'),97080*(10100+13500))
    def test_missing_fees_not_zero(self):
        self.assertEqual(self.wb.value('견적조건 및 견적서','L23'),'미확정')
        self.assertEqual(self.wb.value('분할견적서_1','L16'),'미입력')
        self.assertIn('분할견적서_1',self.wb.cells['스케쥴']['S3'].find(app.tag('f')).text)
    def test_dates_as_excel_values(self):
        self.assertIsInstance(self.wb.raw(self.wb.cells['스케쥴']['E3']),(float,int))
        self.assertEqual(self.wb.date(self.wb.raw(self.wb.cells['스케쥴']['E3'])).strftime('%Y-%m-%d'),'2026-10-31')
    def test_no_historical_values_or_external_formulas(self):
        for name,cells in self.wb.cells.items():
            for address,c in cells.items():
                raw=self.wb.raw(c)
                if isinstance(raw,str):
                    self.assertNotIn('LSE-2630325-6-',raw)
                    self.assertNotIn('T185',raw)
                f=c.find(app.tag('f'))
                if f is not None:
                    self.assertNotIn('[1]',f.text)
                    self.assertNotIn('#REF!',f.text)
        self.assertFalse(any('externalLink' in k for k in self.wb.parts))
    def test_mirrored_pricing(self):
        pb=app.Xlsx(self.result/'Pricing_PKG배정.xlsx')
        h=pb.headers('스케T124 126 127')
        pc=h['PKGNO.']
        for r in range(2,8):self.assertEqual(pb.value('스케T124 126 127',f'{pc}{r}'),pb.value('스케T125',f'N{r}'))
        for r in range(8,26):
            if pb.value('스케T124 126 127',f'L{r}') in ('T126','T127'):self.assertIsNone(pb.value('스케T124 126 127',f'{pc}{r}'))
    def test_existing_assignments_preserved(self):
        cb,pb,packages,rows,lookup,issues=app.analyze(self.cipl,self.result/'Pricing_PKG배정.xlsx',self.selections)
        self.assertEqual([r.pkgs for r in rows],[r['pkgs'] for r in self.manifest['assignments']])
    def test_duplicate_package_stops(self):
        target=self.target/'duplicate.xlsx';mutate(self.cipl,target,'PL Attachment','A7',1)
        with self.assertRaisesRegex(ValueError,'중복'):app.analyze(target,self.pricing,self.selections)
    def test_quantity_mismatch_stops(self):
        target=self.target/'quantity.xlsx';mutate(self.pricing,target,'스케T125','O8',100)
        with self.assertRaisesRegex(ValueError,'필요'):app.analyze(self.cipl,target,self.selections)
    def test_dimension_mismatch_stops(self):
        target=self.target/'dimension.xlsx';mutate(self.pricing,target,'스케T125','P8',999)
        with self.assertRaisesRegex(ValueError,'필요'):app.analyze(self.cipl,target,self.selections)
    def test_date_and_weight_warnings(self):
        text=str(self.manifest['issues'])
        for word in ('불일치','출발일 비어','G.W'):self.assertIn(word,text)
    def test_xml_parts_parse(self):
        for name,data in self.wb.parts.items():
            if name.endswith(('.xml','.rels')):ET.fromstring(data)
    def test_excel_compatibility_on_both_outputs(self):
        for filename in ('ANSWER_검토용.xlsx','Pricing_PKG배정.xlsx'):
            app.validate_excel_structure(self.result/filename)
    def test_phonetic_properties_after_sheet_data(self):
        for root in self.wb.sheets.values():
            children=[c.tag.split('}')[-1] for c in root]
            if 'phoneticPr' in children:self.assertLess(children.index('sheetData'),children.index('phoneticPr'))
    def test_source_style_namespace_metadata_preserved(self):
        root=ET.fromstring(self.wb.parts['xl/styles.xml'])
        self.assertEqual(root.get('{'+app.MC+'}Ignorable'),'x14ac x16r2 xr')
        app.validate_markup_namespaces(self.wb.parts['xl/styles.xml'])
    def test_no_previous_output_overwrite(self):
        first_hash=app.hash_file(self.result/'ANSWER_검토용.xlsx')
        new,_=app.run(self.cipl,self.pricing,self.target,self.selections,self.template)
        self.assertNotEqual(new,self.result)
        self.assertEqual(app.hash_file(self.result/'ANSWER_검토용.xlsx'),first_hash)
    def test_summary_core_costs_link_to_details(self):
        for r in (10,11,13,15,20):
            formula=self.wb.cells['견적조건 및 견적서'][f'L{r}'].find(app.tag('f')).text
            self.assertIn(f"'분할견적서_1'!L{r}",formula)
    def test_sixteenth_schedule_does_not_overwrite_conditions(self):
        import copy
        cb,pb,packages,rows,lookup,issues=app.analyze(self.cipl,self.pricing,self.selections)
        groups=[]
        for i in range(16):
            item=copy.deepcopy(rows[0]);item.mawb=f'{90000000000+i}'
            groups.append({'mawb':item.mawb,'rows':[item],'number':i+1})
        out=app.OutputBook(self.template)
        app.quote(out,cb,groups,'견적조건 및 견적서',issues,{},True)
        target=self.target/'sixteen.xlsx';out.save(target)
        book=app.Xlsx(target)
        self.assertIn(groups[-1]['mawb'],book.value('견적조건 및 견적서','L40'))
        self.assertIn('인도조건',book.value('견적조건 및 견적서','C41'))
    def test_division_by_zero_never_uses_numeric_cache(self):
        target=self.target/'zero_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('1/0',32400))
        with self.assertRaisesRegex(ValueError,'입력 수식 오류.*W3'):app.analyze(self.cipl,target,self.selections)
    def test_circular_formula_never_uses_numeric_cache(self):
        target=self.target/'cycle_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('W3',32400))
        with self.assertRaisesRegex(ValueError,'순환'):app.analyze(self.cipl,target,self.selections)
    def test_ref_error_never_uses_numeric_cache(self):
        target=self.target/'ref_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('SUM(#REF!)',32400))
        with self.assertRaisesRegex(ValueError,'입력 수식 오류'):app.analyze(self.cipl,target,self.selections)
    def test_unsupported_valid_formula_cache_is_disclosed(self):
        target=self.target/'unsupported_cache.xlsx';mutate(self.pricing,target,'스케T124 126 127','W3',app.Formula('ROUND(32400,0)',32400))
        result=app.analyze(self.cipl,target,self.selections)
        self.assertTrue(any('미지원 수식' in str(x) and 'W3' in str(x) for x in result[-1]))
    def test_mirror_same_awb_and_dimensions_uses_pcs(self):
        first=self.target/'mirror_first.xlsx';target=self.target/'mirror_both.xlsx'
        mutate(self.pricing,first,'스케T124 126 127','F5','36911555025')
        mutate(first,target,'스케T125','F5','36911555025')
        result,_=app.run(self.cipl,target,self.target,self.selections,self.template)
        pb=app.Xlsx(result/'Pricing_PKG배정.xlsx')
        six=pb.value('스케T125','N3').split(', ');three=pb.value('스케T125','N5').split(', ')
        self.assertEqual(len(six),6);self.assertEqual(len(three),3)
        self.assertFalse(set(six)&set(three))
    def test_ambiguous_mirrors_do_not_overwrite_and_are_logged(self):
        first=self.target/'ambiguous_first.xlsx';target=self.target/'ambiguous_both.xlsx'
        mutate(self.pricing,first,'스케T124 126 127','F6','27276223512')
        mutate(first,target,'스케T125','F6','27276223512')
        result,manifest=app.run(self.cipl,target,self.target,self.selections,self.template)
        pb=app.Xlsx(result/'Pricing_PKG배정.xlsx')
        self.assertIsNone(pb.value('스케T125','N5'));self.assertIsNone(pb.value('스케T125','N6'))
        self.assertTrue(any('동기화 생략' in str(x) for x in manifest['issues']))
        review=app.Xlsx(result/'ANSWER_검토용.xlsx')
        self.assertTrue(any('동기화 생략' in str(review.raw(c)) for c in review.cells['검토사항'].values()))
    def test_contents_preserved_and_excluded_from_package_totals(self):
        import re
        book=app.Xlsx(self.cipl);ws=book.sheets['PL Attachment'];data=ws.find(app.tag('sheetData'))
        def shifted(match):
            letters,r=match.groups();return letters+str(int(r)+1 if int(r)>=7 else int(r))
        for e in ws.iter():
            if e.tag==app.tag('row') and int(e.get('r'))>=7:e.set('r',str(int(e.get('r'))+1))
            for attr in ('r','ref','sqref','activeCell'):
                if attr in e.attrib:e.set(attr,re.sub(r'(\$?[A-Z]+\$?)(\d+)',shifted,e.get(attr)))
            if e.tag==app.tag('f') and e.text:e.text=re.sub(r'(\$?[A-Z]+\$?)(\d+)',shifted,e.text)
        row=ET.Element(app.tag('row'),{'r':'7'})
        for c,v in [('F','EXTRA CONTENTS'),('G',2),('H','EA')]:app.setcell(row,c,v)
        data.append(row);data[:]=sorted(data,key=lambda r:int(r.get('r')))
        target=self.target/'contents.xlsx'
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
            for name,content in book.parts.items():z.writestr(name,app.serialize_xml(ws,app.namespace_map(content)) if name==book.sheetpaths['PL Attachment'] else content)
        result,_=app.run(target,self.pricing,self.target,self.selections,self.template)
        output=app.Xlsx(result/'ANSWER_검토용.xlsx');s='Packing List_스케줄'
        self.assertEqual(output.value(s,'E7'),'EXTRA CONTENTS')
        self.assertEqual(output.value(s,'F7'),2)
        self.assertIsNone(output.value(s,'A7'))
        self.assertEqual(output.value(s,'F65'),58)
        self.assertIn('SUMIFS',output.cells[s]['F65'].find(app.tag('f')).text)

if __name__=='__main__':unittest.main(verbosity=2)
