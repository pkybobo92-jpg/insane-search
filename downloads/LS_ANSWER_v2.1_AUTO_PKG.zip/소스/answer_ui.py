"""Offline desktop workspace. Visual reference and tokens: DESIGN.md."""
import logging
import os
from pathlib import Path
from queue import Empty, Queue
import threading
import tkinter as tk
from tkinter import filedialog, font, ttk


COLORS = dict(bg='#f4f4f4', paper='#ffffff', ink='#161616', muted='#525252',
              line='#e0e0e0', blue='#0f62fe', hover='#0043ce', pale='#edf5ff',
              green='#0e6027', green_bg='#defbe6', amber='#8a3800', amber_bg='#fff1e6',
              red='#a2191f', red_bg='#fff1f1')


class AnswerWindow(tk.Tk):
    def __init__(self, engine, mode='auto'):
        super().__init__()
        self.engine, self.mode = engine, mode
        self.title(f'LS ANSWER · {engine.MODE_LABELS[mode]} · v{engine.APP_VERSION}')
        self.configure(bg=COLORS['bg'])
        self._icon = tk.PhotoImage(master=self, width=32, height=32)
        self._icon.put(COLORS['blue'], to=(0, 0, 32, 32))
        for rectangle in ((7, 7, 25, 10), (7, 14, 25, 17), (7, 21, 18, 24)):
            self._icon.put('#ffffff', to=rectangle)
        self.iconphoto(True, self._icon)
        width, height = min(1240, self.winfo_screenwidth()-64), min(900, self.winfo_screenheight()-100)
        self.geometry(f'{width}x{height}')
        self.minsize(min(1024, width), min(680, height))
        family = 'Malgun Gothic' if 'Malgun Gothic' in font.families(root=self) else 'Arial'
        self.face = family
        for name in ('TkDefaultFont', 'TkTextFont', 'TkMenuFont'):
            font.nametofont(name, root=self).configure(family=family, size=10)
        self.option_add('*TCombobox*Listbox.font', (family, 10))
        self.paths = {k: tk.StringVar(self, value='') for k in ('cipl', 'pricing', 'output')}
        self.paths['output'].set(str(Path.home()/'Documents'/'LS_ANSWER_결과'))
        self.fx = tk.StringVar(self, value='1450')
        self.tolerance_pct = tk.StringVar(self, value=f"{engine.DEFAULT_AUTO['weight_tolerance_percent']:g}")
        self.tolerance_kg = tk.StringVar(self, value=f"{engine.DEFAULT_AUTO['weight_tolerance_kg']:g}")
        self.estimates = tk.BooleanVar(self, value=engine.DEFAULT_AUTO['auto_assign_estimates'])
        self.combos, self.controls, self.events = {}, [], Queue()
        self.busy = False
        self.analyzed_paths = None
        self.last_folder = None
        self.last_manifest = None
        self.close_after_job = False
        self.status = tk.StringVar(self, value='원본 두 파일을 선택해 주세요.')
        self._style()
        self._build()
        for key in ('cipl', 'pricing'):
            self.paths[key].trace_add('write', self._source_changed)
        for variable in (self.paths['output'], self.fx, self.tolerance_pct, self.tolerance_kg, self.estimates):
            variable.trace_add('write', self._settings_changed)
        self.protocol('WM_DELETE_WINDOW', self._close)
        self.bind('<Control-Return>', lambda event: self.generate())
        self.bind_all('<MouseWheel>', self._wheel, add='+')
        self.bind_all('<FocusIn>', self._focus_visible, add='+')
        self._poll_id = self.after(80, self._poll)
        self._refresh_controls()

    def _style(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('App.TEntry', padding=(10, 9), fieldbackground=COLORS['bg'],
                        bordercolor=COLORS['line'], lightcolor=COLORS['line'], darkcolor=COLORS['line'])
        style.map('App.TEntry', bordercolor=[('focus', COLORS['blue'])],
                  fieldbackground=[('disabled', '#e8e8e8')])
        style.configure('App.TCombobox', padding=(8, 7), fieldbackground=COLORS['bg'],
                        bordercolor=COLORS['line'], arrowsize=14)
        style.map('App.TCombobox', fieldbackground=[('readonly', COLORS['bg'])],
                  selectbackground=[('readonly', COLORS['bg'])], selectforeground=[('readonly', COLORS['ink'])])
        for name, bg, fg in [('Primary', COLORS['blue'], '#ffffff'), ('Secondary', '#ffffff', COLORS['blue'])]:
            style.configure(name+'.TButton', padding=(16, 10), font=(self.face, 10, 'bold'),
                            background=bg, foreground=fg, borderwidth=1, bordercolor=COLORS['blue'],
                            focuscolor=COLORS['blue'], lightcolor=bg, darkcolor=bg)
            style.map(name+'.TButton', background=[('disabled', '#e0e0e0'), ('pressed', '#002d9c'),
                       ('active', COLORS['hover'] if name=='Primary' else COLORS['pale'])],
                      foreground=[('disabled', '#777777'), ('pressed', '#ffffff')],
                      bordercolor=[('disabled', COLORS['line'])])
        style.configure('App.TCheckbutton', background='#ffffff', foreground=COLORS['ink'], padding=(0, 4))
        style.map('App.TCheckbutton', background=[('active', '#ffffff')])
        style.configure('App.Horizontal.TProgressbar', background=COLORS['blue'],
                        troughcolor=COLORS['line'], borderwidth=0, thickness=3)
        style.configure('App.Vertical.TScrollbar', background='#c6c6c6', troughcolor=COLORS['bg'],
                        borderwidth=0, arrowsize=12)

    def _label(self, parent, text='', size=10, bold=False, color=None, bg=None, **kwargs):
        label = tk.Label(parent, text=text, font=(self.face, size, 'bold' if bold else 'normal'),
                         fg=color or COLORS['ink'], bg=bg or parent.cget('bg'), anchor='w',
                         justify='left', borderwidth=0, **kwargs)
        if 'wraplength' in kwargs:
            binding = parent.bind('<Configure>', lambda event, w=label, limit=kwargs['wraplength']:
                                  w.configure(wraplength=min(limit, max(180, event.width-40))) if w.winfo_exists() else None, add='+')
            label.bind('<Destroy>', lambda event: parent.unbind('<Configure>', binding) if parent.winfo_exists() else None, add='+')
        return label

    def _card(self, parent, title, subtitle=None):
        border = tk.Frame(parent, bg=COLORS['line'], padx=1, pady=1)
        border.pack(fill='x', pady=(0, 16))
        card = tk.Frame(border, bg='#ffffff', padx=20, pady=16)
        card.pack(fill='both', expand=True)
        self._label(card, title, 12, True).pack(anchor='w')
        if subtitle:
            label = self._label(card, subtitle, 9, color=COLORS['muted'], wraplength=540)
            label.pack(anchor='w', pady=(4, 12))
            card.bind('<Configure>', lambda event, w=label: w.configure(wraplength=max(200, event.width-40)), add='+')
        return card

    def _build(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        rail = tk.Frame(self, bg=COLORS['ink'], width=192)
        rail.grid(row=0, column=0, sticky='ns')
        rail.grid_propagate(False)
        brand = tk.Frame(rail, bg=COLORS['ink'], padx=24, pady=27)
        brand.pack(fill='x')
        self._label(brand, 'LS ANSWER', 17, True, '#ffffff').pack(anchor='w')
        self._label(brand, '항공 수출 업무 자동화', 9, color='#c6c6c6').pack(anchor='w', pady=(5, 0))
        self.step_labels = []
        for number, title, hint in [('01', '자료 선택', 'CIPL · Pricing'), ('02', '배정 및 생성', '시트와 오차범위 확인'), ('03', '결과 검토', '추정 · 미배정 확인')]:
            item = tk.Frame(rail, bg=COLORS['ink'], padx=24, pady=17)
            item.pack(fill='x')
            label = self._label(item, f'{number}  {title}', 11, True, '#a8a8a8')
            label.pack(anchor='w')
            self._label(item, hint, 9, color='#a8a8a8').pack(anchor='w', pady=(5, 0))
            self.step_labels.append(label)
        foot = tk.Frame(rail, bg=COLORS['ink'], padx=24, pady=24)
        foot.pack(side='bottom', fill='x')
        self._label(foot, '원본 파일 보존', 10, True, '#ffffff').pack(anchor='w')
        self._label(foot, '새 폴더에 결과를 저장합니다.', 9, color='#c6c6c6', wraplength=145).pack(anchor='w', pady=(5, 16))
        self._label(foot, 'Desktop  /  v'+self.engine.APP_VERSION, 9, color='#a8a8a8').pack(anchor='w')
        main = tk.Frame(self, bg=COLORS['bg'])
        main.grid(row=0, column=1, sticky='nsew')
        main.rowconfigure(1, weight=1)
        main.columnconfigure(0, weight=1)
        header = tk.Frame(main, bg='#ffffff', padx=24, pady=19)
        header.grid(row=0, column=0, sticky='ew')
        header.columnconfigure(0, weight=1)
        self._label(header, '워크스페이스  /  출하 요청', 9, color=COLORS['muted']).grid(row=0, column=0, sticky='w')
        self._label(header, '출하 자료 만들기', 22, True).grid(row=1, column=0, sticky='w', pady=(5, 0))
        mode_text = '자동 · 추정 배정' if self.mode=='auto' else self.engine.MODE_LABELS[self.mode]
        self._label(header, mode_text, 10, True, COLORS['hover'], COLORS['pale'], padx=12, pady=7).grid(row=0, column=1, rowspan=2, sticky='e', padx=(12, 0))
        viewport = tk.Frame(main, bg=COLORS['bg'])
        viewport.grid(row=1, column=0, sticky='nsew')
        viewport.columnconfigure(0, weight=1)
        viewport.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(viewport, bg=COLORS['bg'], highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        scroll = ttk.Scrollbar(viewport, orient='vertical', command=self.canvas.yview, style='App.Vertical.TScrollbar')
        scroll.grid(row=0, column=1, sticky='ns')
        self.canvas.configure(yscrollcommand=scroll.set)
        self.body = tk.Frame(self.canvas, bg=COLORS['bg'], padx=24, pady=20)
        window = self.canvas.create_window((0, 0), anchor='nw', window=self.body)
        self.canvas.bind('<Configure>', lambda event: self.canvas.itemconfigure(window, width=event.width))
        self.body.bind('<Configure>', lambda event: self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.body.columnconfigure(0, weight=1)
        self.body.columnconfigure(1, minsize=268)
        left = tk.Frame(self.body, bg=COLORS['bg'])
        left.grid(row=0, column=0, sticky='new', padx=(0, 20))
        right = tk.Frame(self.body, bg=COLORS['bg'], width=268)
        right.grid(row=0, column=1, sticky='new')
        self._build_sources(left)
        self._build_settings(left)
        self._build_summary(right)
        footer = tk.Frame(main, bg='#ffffff', padx=24, pady=16, highlightthickness=1, highlightbackground=COLORS['line'])
        footer.grid(row=2, column=0, sticky='ew')
        footer.columnconfigure(0, weight=1)
        self.footer_note = self._label(footer, '파일 분석부터 진행하세요.', 10, color=COLORS['muted'], wraplength=400)
        self.footer_note.grid(row=0, column=0, sticky='w', padx=(0, 12))
        self.generate_button = ttk.Button(footer, text='ANSWER 생성   →', style='Primary.TButton', command=self.generate)
        self.generate_button.grid(row=0, column=1, sticky='e')
        self._set_step(0)

    def _build_sources(self, parent):
        card = self._card(parent, '원본 파일', 'CIPL 실측 자료와 Pricing 파일을 연결합니다.')
        self.path_entries = {}
        self.file_hints = {}
        for key, title, help_text in [('cipl', 'CIPL 실측 자료', 'PL Attachment의 실제 PKG 번호를 사용합니다.'),
                                      ('pricing', 'Pricing 자료', '자동 모드는 Pricing의 PKG 번호 없이도 사용합니다.'),
                                      ('output', '결과 저장 폴더', '실행할 때마다 별도의 결과 폴더를 만듭니다.')]:
            self._label(card, title, 10, True).pack(anchor='w', pady=(8, 5))
            row = tk.Frame(card, bg='#ffffff')
            row.pack(fill='x')
            row.columnconfigure(0, weight=1)
            entry = ttk.Entry(row, textvariable=self.paths[key], style='App.TEntry')
            entry.grid(row=0, column=0, sticky='ew')
            button = ttk.Button(row, text='선택', width=5, style='Secondary.TButton', command=lambda k=key: self.browse(k))
            button.grid(row=0, column=1, padx=(8, 0))
            self.path_entries[key] = entry
            self.controls.extend((entry, button))
            hint = self._label(card, help_text, 9, color=COLORS['muted'], wraplength=450)
            hint.pack(anchor='w', pady=(5, 6))
            self.file_hints[key] = (hint, help_text)
        self.analyze_button = ttk.Button(card, text='파일 분석', style='Secondary.TButton', command=self.analyze)
        self.analyze_button.pack(anchor='e', pady=(10, 0))
        sheet_card = self._card(parent, 'TASK별 적용 시트')
        self.task_frame = tk.Frame(sheet_card, bg='#ffffff')
        self.task_frame.pack(fill='x', pady=(12, 0))
        self._empty_tasks()

    def _build_settings(self, parent):
        card = self._card(parent, '배정 설정')
        row = tk.Frame(card, bg='#ffffff')
        row.pack(fill='x', pady=(14, 10))
        self._label(row, '적용환율', 10, True).pack(side='left', padx=(0, 16))
        self.fx_entry = ttk.Entry(row, textvariable=self.fx, width=12, style='App.TEntry')
        self.fx_entry.pack(side='left')
        self._label(row, 'KRW / USD', 9, color=COLORS['muted']).pack(side='left', padx=10)
        self.controls.append(self.fx_entry)
        if self.mode=='auto':
            self._label(card, '허용 중량 차이', 10, True).pack(anchor='w', pady=(7, 6))
            line = tk.Frame(card, bg='#ffffff')
            line.pack(fill='x')
            for variable, suffix in [(self.tolerance_pct, '%'), (self.tolerance_kg, 'kg')]:
                entry = ttk.Entry(line, textvariable=variable, width=7, style='App.TEntry')
                entry.pack(side='left')
                self.controls.append(entry)
                self._label(line, suffix, 10, color=COLORS['muted']).pack(side='left', padx=(6, 15))
            self._label(card, '두 범위 중 큰 값을 적용합니다. 기준: Pricing G.W/PC', 9, color=COLORS['muted'], wraplength=450).pack(anchor='w', pady=(6, 12))
            self.estimate_check = ttk.Checkbutton(card, text='모호한 화물도 추정 배정', variable=self.estimates, style='App.TCheckbutton')
            self.estimate_check.pack(anchor='w')
            self.controls.append(self.estimate_check)
            self.estimate_hint = self._label(card, '', 9, color=COLORS['muted'], wraplength=450)
            self.estimate_hint.pack(anchor='w', pady=(3, 0))
            card.bind('<Configure>', lambda event: self.estimate_hint.configure(wraplength=max(200, event.width-40)), add='+')
        else:
            self._label(card, 'Pricing에 적힌 PKG를 검증해 사용합니다.\n번호·수량·TASK·치수가 맞지 않으면 생성하지 않습니다.', 9,
                        color=COLORS['muted'], wraplength=450).pack(anchor='w', pady=(2, 0))

    def _build_summary(self, parent):
        card = self._card(parent, '작업 요약')
        self.summary_hint = self._label(card, '파일 분석 후 집계합니다.', 9, color=COLORS['muted'], wraplength=220)
        self.summary_hint.pack(anchor='w', pady=(5, 15))
        self.metrics = {}
        grid = tk.Frame(card, bg='#ffffff')
        grid.pack(fill='x')
        for i, (key, title, color) in enumerate([('packages', '전체 PKG', COLORS['ink']), ('awbs', 'AWB', COLORS['ink']),
                                               ('estimated', '추정배정', COLORS['amber']), ('pending', '미배정', COLORS['red'])]):
            cell = tk.Frame(grid, bg='#ffffff', padx=5, pady=12)
            cell.grid(row=i//2, column=i%2, sticky='nsew')
            grid.columnconfigure(i%2, weight=1, uniform='metric')
            self._label(cell, title, 9, color=COLORS['muted']).pack(anchor='w')
            self.metrics[key] = self._label(cell, '—', 26, True, color)
            self.metrics[key].pack(anchor='w', pady=(3, 0))
        self.state_banner = self._label(card, '자료 선택 대기', 10, True, COLORS['hover'], COLORS['pale'], padx=10, pady=9, wraplength=205)
        self.state_banner.pack(fill='x', pady=(12, 10))
        self.progress = ttk.Progressbar(card, mode='indeterminate', style='App.Horizontal.TProgressbar')
        self.status_label = self._label(card, textvariable=self.status, size=9, color=COLORS['muted'], wraplength=220)
        self.status_label.pack(fill='x')
        results = self._card(parent, '결과 확인')
        self.folder_button = ttk.Button(results, text='결과 폴더 열기', style='Secondary.TButton', command=lambda: self.open_result(False))
        self.folder_button.pack(fill='x', pady=(14, 8))
        self.log_button = ttk.Button(results, text='검토 로그 보기', style='Secondary.TButton', command=lambda: self.open_result(True))
        self.log_button.pack(fill='x')
        note = tk.Frame(parent, bg=COLORS['amber_bg'], padx=16, pady=14)
        note.pack(fill='x')
        self._label(note, '출고 전 확인', 10, True, COLORS['amber']).pack(anchor='w')
        self._label(note, '추정배정과 미배정 내역은\n실제 출고 자료와 대조하세요.\n누락된 단가·일정도 확인해 주세요.', 9,
                    color=COLORS['amber'], wraplength=230).pack(anchor='w', pady=(6, 0))

    def _empty_tasks(self):
        for widget in self.task_frame.winfo_children(): widget.destroy()
        self.combos.clear()
        self._label(self.task_frame, '파일 분석 후 적용 시트가 표시됩니다.', 9, color=COLORS['muted'], wraplength=450).pack(anchor='w')

    def _set_step(self, current):
        for i, label in enumerate(self.step_labels):
            label.configure(fg='#ffffff' if i==current else '#78a9ff' if i<current else '#a8a8a8')

    def _banner(self, text, tone='info'):
        fg, bg = {'info': (COLORS['hover'], COLORS['pale']), 'success': (COLORS['green'], COLORS['green_bg']),
                  'warning': (COLORS['amber'], COLORS['amber_bg']), 'error': (COLORS['red'], COLORS['red_bg'])}[tone]
        self.state_banner.configure(text=text, fg=fg, bg=bg)

    def _clear_result(self):
        self.last_folder = self.last_manifest = None
        for key in ('estimated', 'pending'): self.metrics[key].configure(text='—')

    def _source_changed(self, *args):
        for key in ('cipl', 'pricing'):
            label, hint = self.file_hints[key]
            path = self.paths[key].get().strip()
            label.configure(text=Path(path).name if path else hint)
        self.analyzed_paths = None
        self._clear_result()
        self._empty_tasks()
        for key in ('packages', 'awbs'): self.metrics[key].configure(text='—')
        self.summary_hint.configure(text='파일 분석 후 집계합니다.')
        self._banner('자료 선택 대기')
        self.status.set('입력 파일을 변경했습니다. 다시 분석해 주세요.')
        self._set_step(0)
        self._refresh_controls()

    def _settings_changed(self, *args):
        self._clear_result()
        if self.analyzed_paths:
            self._banner('배정 설정 확인')
            self.status.set('설정을 확인한 뒤 ANSWER를 생성하세요.')
            self._set_step(1)
        if self.mode=='auto':
            self.estimate_hint.configure(text='동일 조건·오차 초과 화물도 가까운 조합으로 배정하고 표시합니다.' if self.estimates.get()
                                         else '연결이 모호한 화물은 미배정으로 남깁니다.')
        self._refresh_controls()

    def _selection_changed(self, event=None):
        self.metrics['awbs'].configure(text='—')
        self.summary_hint.configure(text='변경한 시트의 AWB는 생성 시 집계합니다.')
        self._settings_changed()

    def _refresh_controls(self):
        for control in self.controls: control.configure(state='disabled' if self.busy else 'normal')
        for combo in self.combos.values(): combo.configure(state='disabled' if self.busy else 'readonly')
        has_paths = all(self.paths[k].get().strip() for k in ('cipl', 'pricing'))
        self.analyze_button.configure(state='normal' if has_paths and not self.busy else 'disabled')
        current = tuple(self.paths[k].get().strip() for k in ('cipl', 'pricing'))
        ready = (self.analyzed_paths==current and bool(self.combos) and
                 all(combo.get() for combo in self.combos.values()) and bool(self.paths['output'].get().strip()))
        self.generate_button.configure(state='normal' if ready and not self.busy else 'disabled')
        for button in (self.folder_button, self.log_button): button.configure(state='normal' if self.last_folder and not self.busy else 'disabled')
        if not self.busy:
            self.footer_note.configure(text='결과를 검토하거나 설정을 바꿔 다시 생성하세요.' if self.last_folder else
                                       '준비되었습니다. ANSWER를 생성할 수 있습니다.' if ready else
                                       'TASK별 Pricing 시트를 선택해 주세요.' if self.analyzed_paths else '파일 분석부터 진행하세요.')
        if self.mode=='auto' and not self.estimate_hint.cget('text'):
            self.estimate_hint.configure(text='동일 조건·오차 초과 화물도 가까운 조합으로 배정하고 표시합니다.')

    def browse(self, key):
        if self.busy: return
        if key=='output': path=filedialog.askdirectory(parent=self, title='결과 저장 폴더')
        else: path=filedialog.askopenfilename(parent=self, title='CIPL 실측 자료 선택' if key=='cipl' else 'Pricing 자료 선택', filetypes=[('Excel 통합문서', '*.xlsx')])
        if path: self.paths[key].set(path)

    def analyze(self):
        if self.busy: return
        paths = tuple(self.paths[k].get().strip() for k in ('cipl', 'pricing'))
        if not all(paths): return
        def inspect():
            choices = self.engine.default_selections(*paths)
            pricing = self.engine.Xlsx(paths[1])
            packages = self.engine.read_packages(self.engine.Xlsx(paths[0]))
            awbs = None
            if all(choices.values()):
                rows = self.engine.read_pricing(pricing, choices, sorted(choices), [], use_explicit=self.mode!='auto')
                awbs = len({r.mawb for r in rows})
            return paths, choices, list(pricing.sheets), len(packages), awbs
        self._start('analysis', inspect, 'TASK와 적용 시트를 읽고 있습니다.')

    def generate(self):
        if self.busy or self.generate_button.instate(['disabled']): return
        try:
            settings = {'exchange_rate': self.engine.num(self.fx.get(), '환율', True), 'matching_mode': self.mode}
            if self.mode=='auto':
                settings.update(self.engine.auto_options({'weight_tolerance_kg': self.tolerance_kg.get(),
                                'weight_tolerance_percent': self.tolerance_pct.get(), 'auto_assign_estimates': self.estimates.get()}))
        except ValueError as error:
            self._fail(str(error), '입력값 확인')
            return
        paths = {k: v.get().strip() for k, v in self.paths.items()}
        selections = {k: combo.get() for k, combo in self.combos.items()}
        self._start('generation', lambda: self.engine.run(paths['cipl'], paths['pricing'], paths['output'], selections, settings=settings),
                    '화물을 대조하고 ANSWER를 만들고 있습니다.')

    def _start(self, kind, function, message):
        if kind=='analysis':
            self.analyzed_paths = None
            self._empty_tasks()
            self._clear_result()
            for key in ('packages', 'awbs'): self.metrics[key].configure(text='—')
        self.busy = True
        self.status.set(message)
        self.footer_note.configure(text='처리 중입니다. 잠시 기다려 주세요.')
        self._banner('파일 분석 중' if kind=='analysis' else 'ANSWER 생성 중')
        self.progress.pack(fill='x', pady=(0, 10), before=self.status_label)
        self.progress.start(12)
        self._refresh_controls()
        def worker():
            try: result = function()
            except Exception as error:
                logging.exception('화면 작업 실패: %s', kind)
                self.events.put((kind, None, str(error)))
            else: self.events.put((kind, result, None))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self):
        try: kind, result, error = self.events.get_nowait()
        except Empty: pass
        else:
            self.busy = False
            self.progress.stop()
            self.progress.pack_forget()
            if error:
                if kind=='analysis': self.analyzed_paths=None; self._empty_tasks()
                self._clear_result()
                self._fail(error, '파일 확인 필요' if kind=='analysis' else '생성 실패')
            elif kind=='analysis': self._analysis_done(result)
            else: self._generation_done(result)
            self._refresh_controls()
            if self.close_after_job:
                self.destroy()
                return
        self._poll_id = self.after(80, self._poll)

    def _analysis_done(self, result):
        paths, choices, names, count, awbs = result
        self._clear_result()
        self.analyzed_paths = paths
        for widget in self.task_frame.winfo_children(): widget.destroy()
        self.combos.clear()
        self.task_frame.columnconfigure(1, weight=1)
        for i, (task, selected) in enumerate(choices.items()):
            self._label(self.task_frame, task, 10, True, COLORS['hover']).grid(row=i, column=0, sticky='w', padx=(0, 18), pady=5)
            combo = ttk.Combobox(self.task_frame, values=names, state='readonly', style='App.TCombobox')
            combo.set(selected)
            combo.grid(row=i, column=1, sticky='ew', pady=5)
            combo.bind('<<ComboboxSelected>>', self._selection_changed)
            self.combos[task] = combo
        self.metrics['packages'].configure(text=str(count))
        self.metrics['awbs'].configure(text=str(awbs) if awbs is not None else '—')
        self.summary_hint.configure(text='입력 기준 집계 · 배정은 생성 시 검증합니다.')
        self._banner('파일 분석 완료')
        self.status.set(f'TASK {len(choices)}개를 읽었습니다. 적용 시트와 배정 설정을 확인하세요.')
        self._set_step(1)

    def _generation_done(self, result):
        folder, manifest = result
        self.last_folder, self.last_manifest = Path(folder), manifest
        for key, value in [('packages', manifest['packages']), ('awbs', manifest['awbs']),
                           ('estimated', manifest['estimated_packages']), ('pending', manifest['pending_packages'])]:
            self.metrics[key].configure(text=str(value))
        review = manifest['estimated_packages'] or manifest['pending_packages'] or any(i[0] in ('확인필요', '미입력') for i in manifest.get('issues', []))
        self._banner('완료 · 검토사항 확인' if review else '결과 생성 완료', 'warning' if review else 'success')
        self.summary_hint.configure(text=f"{manifest['assigned_packages']} / {manifest['packages']}개 배정 완료")
        self.status.set('결과 폴더에서 ANSWER와 검토 로그를 확인하세요.\n\n'+str(folder))
        self._set_step(2)
        self.canvas.yview_moveto(0)

    def _fail(self, message, title):
        self._banner(title, 'error')
        self.status.set(message)
        self.canvas.yview_moveto(0)

    def open_result(self, log=False):
        if self.busy or self.last_folder is None: return
        target = self.last_folder/'검토로그.txt' if log else self.last_folder
        try: os.startfile(target)
        except OSError as error:
            logging.exception('결과 열기 실패: %s', target)
            self._fail(f'{target}\n\n{error}', '결과 열기 실패')

    def _wheel(self, event):
        if self.winfo_containing(event.x_root, event.y_root) is not None:
            widget = event.widget
            if isinstance(widget, ttk.Combobox): return
            self.canvas.yview_scroll(-int(event.delta/120), 'units')

    def _focus_visible(self, event):
        widget = event.widget
        if not str(widget).startswith(str(self.body)+'.'): return
        height = self.canvas.winfo_height()
        if height<50: return
        top = widget.winfo_rooty()-self.body.winfo_rooty()
        visible = self.canvas.canvasy(0)
        if top<visible or top+widget.winfo_height()>visible+height:
            total = max(self.body.winfo_height(), height)
            self.canvas.yview_moveto(max(0, top-20)/total)

    def _close(self):
        if self.busy:
            self.close_after_job = True
            self.status.set('현재 작업과 결과 저장을 마친 뒤 종료합니다.')
            return
        self.destroy()

    def destroy(self):
        if getattr(self, '_poll_id', None):
            self.after_cancel(self._poll_id)
            self._poll_id = None
        super().destroy()
