"""GUI component tests: set LS_GUI_TESTS=1. No desktop input or screen capture."""
import os
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import answer_app as app
from answer_ui import AnswerWindow


@unittest.skipUnless(os.environ.get('LS_GUI_TESTS')=='1', 'LS_GUI_TESTS=1로 GUI 구성요소 검사 활성화')
class WindowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.manifest = dict(packages=91, awbs=4, assigned_packages=91, estimated_packages=60, pending_packages=0, issues=[])
        self.engine = SimpleNamespace(APP_VERSION=app.APP_VERSION, MODE_LABELS=app.MODE_LABELS, DEFAULT_AUTO=app.DEFAULT_AUTO,
            num=app.num, auto_options=app.auto_options, default_selections=Mock(return_value={'T112':'T111, T112'}),
            Xlsx=Mock(return_value=SimpleNamespace(sheets={'T111, T112':None})),
            read_packages=Mock(return_value=list(range(91))),
            read_pricing=Mock(return_value=[SimpleNamespace(mawb=str(i)) for i in range(4)]),
            run=Mock(return_value=(Path(self.temp.name), self.manifest)))
        self.window = None
        self.callbacks = []

    def make(self, mode='auto'):
        self.window = AnswerWindow(self.engine, mode)
        self.window.withdraw()
        self.window.report_callback_exception = lambda *args: self.callbacks.append(args)
        self.window.update_idletasks()
        return self.window

    def wait(self, condition, timeout=4):
        deadline = time.monotonic()+timeout
        while not condition():
            self.assertLess(time.monotonic(), deadline, 'UI operation timed out')
            self.window.update()
            time.sleep(.01)
        self.window.update_idletasks()

    def analyzed(self, mode='auto'):
        w = self.make(mode)
        for key, value in [('cipl','cipl.xlsx'), ('pricing','pricing.xlsx'), ('output',self.temp.name)]: w.paths[key].set(value)
        w.analyze()
        self.wait(lambda: not w.busy)
        return w

    def generated(self):
        w = self.analyzed()
        w.generate()
        self.wait(lambda: not w.busy)
        return w

    def tearDown(self):
        if self.window is not None:
            try:
                self.window.update_idletasks()
                if self.window.winfo_exists(): self.window.destroy()
            except Exception as error:
                if error.__class__.__name__!='TclError': raise
        self.temp.cleanup()
        self.assertEqual(self.callbacks, [], 'Tk callback failure')

    def test_empty_state_has_no_invented_counts_and_cannot_generate(self):
        w = self.make()
        self.assertTrue(w.generate_button.instate(['disabled']))
        self.assertTrue(w.analyze_button.instate(['disabled']))
        self.assertTrue(all(label.cget('text')=='—' for label in w.metrics.values()))
        self.assertEqual(w.tolerance_pct.get(), '30')
        self.assertEqual(w.tolerance_kg.get(), '10')
        self.assertTrue(w.estimates.get())

    def test_analysis_shows_actual_input_summary_and_sheet(self):
        w = self.analyzed()
        self.assertEqual(w.metrics['packages'].cget('text'), '91')
        self.assertEqual(w.metrics['awbs'].cget('text'), '4')
        self.assertEqual(w.combos['T112'].get(), 'T111, T112')
        self.assertFalse(w.generate_button.instate(['disabled']))
        self.assertEqual(w.metrics['estimated'].cget('text'), '—')

    def test_changed_source_clears_stale_results_and_requires_reanalysis(self):
        w = self.generated()
        w.paths['cipl'].set('different.xlsx')
        w.update()
        self.assertIsNone(w.last_folder)
        self.assertFalse(w.combos)
        self.assertTrue(w.generate_button.instate(['disabled']))
        self.assertTrue(all(label.cget('text')=='—' for label in w.metrics.values()))

    def test_changed_settings_clear_result_but_keep_valid_sheets(self):
        w = self.generated()
        w.fx.set('1500')
        self.assertIsNone(w.last_folder)
        self.assertEqual(w.combos['T112'].get(), 'T111, T112')
        self.assertEqual(w.metrics['estimated'].cget('text'), '—')
        self.assertFalse(w.generate_button.instate(['disabled']))
        self.assertTrue(w.folder_button.instate(['disabled']))

    def test_generation_passes_settings_and_displays_real_counts(self):
        w = self.analyzed()
        w.fx.set('1500');w.tolerance_pct.set('45');w.tolerance_kg.set('20');w.estimates.set(False)
        w.generate();self.wait(lambda: not w.busy)
        settings = self.engine.run.call_args.kwargs['settings']
        self.assertEqual(settings, dict(exchange_rate=1500, matching_mode='auto', weight_tolerance_percent=45, weight_tolerance_kg=20, auto_assign_estimates=False))
        self.assertEqual(w.metrics['estimated'].cget('text'), '60')
        self.assertEqual(w.metrics['pending'].cget('text'), '0')
        self.assertFalse(w.folder_button.instate(['disabled']))
        self.assertIn('검토사항', w.state_banner.cget('text'))

    def test_explicit_mode_preserves_its_fixed_mode_and_has_no_tolerance_controls(self):
        w = self.analyzed('explicit')
        self.assertFalse(hasattr(w, 'estimate_check'))
        w.generate();self.wait(lambda: not w.busy)
        self.assertEqual(self.engine.run.call_args.kwargs['settings'], dict(exchange_rate=1450, matching_mode='explicit'))

    def test_invalid_exchange_rate_stops_before_worker(self):
        w = self.analyzed();w.fx.set('0');w.generate()
        self.engine.run.assert_not_called()
        self.assertFalse(w.busy)
        self.assertEqual(w.state_banner.cget('text'), '입력값 확인')

    def test_worker_failure_is_visible_and_releases_controls(self):
        w = self.analyzed()
        self.engine.run.side_effect=ValueError('치수별 수량 불일치')
        with self.assertLogs(level='ERROR'):
            w.generate();self.wait(lambda: not w.busy)
        self.assertIn('치수별 수량 불일치', w.status.get())
        self.assertIsNone(w.last_folder)
        self.assertFalse(w.generate_button.instate(['disabled']))

    def test_busy_state_blocks_duplicate_execution_and_all_input_changes(self):
        w = self.analyzed();gate=threading.Event()
        self.engine.run.side_effect=lambda *args, **kwargs: (gate.wait(2), (Path(self.temp.name), self.manifest))[1]
        try:
            w.generate();w.generate()
            self.assertTrue(w.busy)
            self.assertTrue(all(widget.instate(['disabled']) for widget in w.controls))
            self.assertTrue(w.combos['T112'].instate(['disabled']))
        finally: gate.set()
        self.wait(lambda: not w.busy)
        self.assertEqual(self.engine.run.call_count, 1)

    def test_result_actions_use_generated_folder_and_review_log(self):
        w = self.generated()
        with patch('answer_ui.os.startfile') as opener:
            w.open_result();w.open_result(True)
        self.assertEqual([c.args[0] for c in opener.call_args_list], [Path(self.temp.name), Path(self.temp.name)/'검토로그.txt'])

    def test_reanalysis_failure_does_not_leave_old_input_counts(self):
        w = self.analyzed();self.engine.default_selections.side_effect=ValueError('CIPL 헤더 오류')
        with self.assertLogs(level='ERROR'):
            w.analyze();self.wait(lambda: not w.busy)
        self.assertIsNone(w.analyzed_paths)
        self.assertTrue(all(label.cget('text')=='—' for label in w.metrics.values()))
        self.assertTrue(w.generate_button.instate(['disabled']))

    def test_whitespace_around_input_paths_does_not_block_generation(self):
        w = self.make()
        w.paths['cipl'].set(' cipl.xlsx ');w.paths['pricing'].set(' pricing.xlsx ')
        w.analyze();self.wait(lambda: not w.busy)
        self.assertFalse(w.generate_button.instate(['disabled']))
        self.engine.default_selections.assert_called_once_with('cipl.xlsx', 'pricing.xlsx')

    def test_close_during_generation_waits_for_completed_save(self):
        w = self.analyzed();gate=threading.Event()
        self.engine.run.side_effect=lambda *args, **kwargs: (gate.wait(2), (Path(self.temp.name), self.manifest))[1]
        with patch.object(w, 'destroy') as close:
            try:
                w.generate();w._close()
                self.assertTrue(w.close_after_job)
                close.assert_not_called()
                self.assertIn('저장', w.status.get())
            finally: gate.set()
            self.wait(lambda: not w.busy)
            close.assert_called_once()


if __name__=='__main__': unittest.main(verbosity=2)
